# PlayzAI 1.4.0 Dashboard

A standalone premium web control center for the existing PlayzAI backend. It is a React + TypeScript + Vite static application with a dark-first clay/glass visual system, truthful backend state, authenticated REST calls, and an authenticated WebSocket status channel.

## Requirements

- Node.js 20 or newer
- A reachable PlayzAI backend
- A registered device ID and API key from the backend
- HTTPS for production backend URLs (loopback HTTP is useful for local development)

## Install and run

```bash
npm install
cp .env.example .env
# For a local backend, set VITE_API_BASE_URL=/playzai-backend in .env.
npm run dev
```

The Vite development server includes a local-only `/playzai-backend` proxy. Its target is `VITE_DEV_BACKEND_URL` (defaulting to a loopback development backend only when you explicitly use the proxy). For a remote backend, enter its full URL in the connection screen instead.

Open the local URL printed by Vite. Enter the backend URL, device ID, and API key on the connection screen. The dashboard creates a backend session when the API supports it and then uses the authenticated session for dashboard calls.

The runtime form is the source of truth for the backend URL. `VITE_API_BASE_URL` is optional and is only a build-time default; it is not a secret. Production static hosting requires the backend to allow the dashboard origin with appropriate CORS policy.

## Validate and build

```bash
npm run typecheck
npm run lint
npm test
npm run build
npm run preview
```

The production output is written to `dist/`.

## What is connected

The dashboard uses the existing backend contracts rather than inventing a frontend data layer:

- `/health`
- `/api/auth/session`
- `/api/auth/status`
- `/api/devices`
- `/api/pcs`
- `/api/security/events`
- `/api/commands`
- `/api/chat`
- `/api/pairing/codes`
- `/api/command`
- `/api/pcs/{pc_id}/wake`
- `/api/devices/revoke`
- `/api/security/lockdown`
- `/api/security/unlock`
- `/api/whatsapp/status`
- authenticated `/ws`

The backend remains authoritative. If an endpoint is unavailable, the dashboard says so. It does not fabricate PC telemetry, AI replies, WhatsApp delivery, uptime, active-session counts, or command success.

## Authentication and security

The dashboard uses the existing device/API-key and session-token system. Credentials are held in `sessionStorage` for the current browser session and are never placed in the JavaScript source or `.env.example`. The owner master key is held only in React memory while a privileged action is performed. Production deployments must use HTTPS.

No arbitrary shell, CMD, or PowerShell control is exposed. PC controls map only to backend allowlisted actions and dangerous actions use confirmation dialogs.

## GitHub Pages deployment

This is a static Vite build and can be deployed to GitHub Pages. The included workflow is `.github/workflows/dashboard.yml`.

1. Push this project to a GitHub repository.
2. In repository Settings, enable Pages using **GitHub Actions**.
3. Optionally add a repository variable named `VITE_API_BASE_URL` containing the public HTTPS backend URL. Leave it unset if operators should enter the URL at runtime.
4. Push to `main` or run the workflow manually.

The workflow runs typecheck, lint, tests, build, and uploads/deploys `dist/`.

## Troubleshooting

- **Backend offline:** Confirm the URL is reachable from the browser and that CORS allows the dashboard origin.
- **401 / 403:** Check the device ID, API key, session expiry, revocation, and backend lockdown state. Log out and reconnect after changing credentials.
- **429:** The backend rate limiter is active. Wait for the returned retry window.
- **AI not configured:** Configure the backend AI provider; the dashboard intentionally displays the backend error.
- **No PC:** Pair a Windows agent and wait for an authenticated heartbeat. A registered device without a fresh heartbeat is not displayed as online.
- **WhatsApp not configured:** Add the official Cloud API credentials and webhook configuration to the backend only. Do not put them in this frontend.
