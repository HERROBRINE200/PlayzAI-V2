"""PlayzAI backend: authenticated AI gateway, device control, security, agent queue,
Wake-on-LAN, realtime status, and official WhatsApp Cloud API boundaries.

Provider and messaging credentials are backend-only. Blank provider credentials
produce truthful unavailable responses; no remote result is fabricated.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import socket
import sqlite3
import time
import uuid
from collections import defaultdict, deque
from contextlib import closing
from typing import Any, Callable

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException, Query, Request, WebSocket, WebSocketDisconnect, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field

load_dotenv()

DB = os.getenv("PLAYZAI_DB", "playzai.db")
API_VERSION = "1.0.0"
BLOCK_SECONDS = int(os.getenv("AUTH_BLOCK_SECONDS", "900"))
AUTH_FAILURE_LIMIT = int(os.getenv("AUTH_FAILURE_LIMIT", "5"))
RATE_LIMIT_PER_MINUTE = int(os.getenv("RATE_LIMIT_PER_MINUTE", "30"))
AUTH_RATE_LIMIT_PER_MINUTE = int(os.getenv("AUTH_RATE_LIMIT_PER_MINUTE", "12"))
AI_TIMEOUT_SECONDS = float(os.getenv("AI_TIMEOUT_SECONDS", "20"))
AI_MAX_TOKENS = int(os.getenv("AI_MAX_TOKENS", "800"))
AI_API_KEY = os.getenv("AI_API_KEY", "").strip()
AI_BASE_URL = os.getenv("AI_BASE_URL", "").strip().rstrip("/")
AI_MODEL = os.getenv("AI_MODEL", "").strip()
AUTH_SECRET = os.getenv("AUTH_SECRET", "").strip()
ENROLLMENT_SECRET = os.getenv("PLAYZAI_ENROLLMENT_SECRET", "").strip()
MASTER_KEY = os.getenv("PLAYZAI_MASTER_KEY", "").strip()
WHATSAPP_VERIFY_TOKEN = os.getenv("WHATSAPP_VERIFY_TOKEN", "").strip()
WHATSAPP_ACCESS_TOKEN = os.getenv("WHATSAPP_ACCESS_TOKEN", "").strip()
WHATSAPP_PHONE_NUMBER_ID = os.getenv("WHATSAPP_PHONE_NUMBER_ID", "").strip()
WHATSAPP_API_VERSION = os.getenv("WHATSAPP_API_VERSION", "v21.0").strip()
WHATSAPP_WEBHOOK_SECRET = os.getenv("WHATSAPP_WEBHOOK_SECRET", "").strip()
SYSTEM_PROMPT = os.getenv(
    "AI_SYSTEM_PROMPT",
    "You are PlayzAI, a helpful assistant. Be clear, safe, and concise. Never claim an action was performed unless an authorized tool confirms it.",
)

app = FastAPI(title="PlayzAI API", version=API_VERSION)


class ProviderNotConfigured(Exception): pass
class ProviderUnavailable(Exception): pass
class ProviderTimedOut(Exception): pass
class ProviderRejected(Exception): pass


class SlidingWindowLimiter:
    def __init__(self) -> None:
        self._hits: dict[str, deque[float]] = defaultdict(deque)

    def clear(self) -> None:
        self._hits.clear()

    def allow(self, key: str, limit: int, window_seconds: int = 60) -> tuple[bool, int]:
        current = time.time()
        hits = self._hits[key]
        while hits and hits[0] <= current - window_seconds:
            hits.popleft()
        if len(hits) >= max(1, limit):
            return False, max(1, int(hits[0] + window_seconds - current) + 1)
        hits.append(current)
        return True, 0


limiter = SlidingWindowLimiter()


def now() -> float:
    return time.time()


def request_id(request: Request) -> str:
    return getattr(request.state, "request_id", "unknown")


def client_ip(request: Request) -> str:
    return request.client.host if request.client else "unknown"


def hash_credential(value: str) -> str:
    secret = AUTH_SECRET.encode() if AUTH_SECRET else b"playzai-development-auth"
    return hmac.new(secret, value.encode(), hashlib.sha256).hexdigest()


def safe_detail(value: str, max_length: int = 240) -> str:
    return str(value).replace("\n", " ").replace("\r", " ")[:max_length]


def database() -> sqlite3.Connection:
    connection = sqlite3.connect(DB, timeout=10, check_same_thread=False)
    connection.row_factory = sqlite3.Row
    return connection


def init_db() -> None:
    with closing(database()) as connection:
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS devices(
                id TEXT PRIMARY KEY, name TEXT NOT NULL, key_hash TEXT NOT NULL,
                created REAL NOT NULL, last_seen REAL, blocked_until REAL DEFAULT 0,
                failed_attempts INTEGER DEFAULT 0, failed_window_start REAL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS events(
                id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL NOT NULL, source TEXT NOT NULL,
                ip TEXT NOT NULL, event TEXT NOT NULL, detail TEXT DEFAULT '', request_id TEXT DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS sessions(
                id TEXT PRIMARY KEY, device_id TEXT NOT NULL, token_hash TEXT NOT NULL,
                created REAL NOT NULL, expires_at REAL NOT NULL, revoked INTEGER DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS conversations(
                id TEXT PRIMARY KEY, owner_device_id TEXT NOT NULL, title TEXT NOT NULL,
                created REAL NOT NULL, updated REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS messages(
                id TEXT PRIMARY KEY, conversation_id TEXT NOT NULL, device_id TEXT NOT NULL,
                role TEXT NOT NULL, body TEXT NOT NULL, created REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS commands(
                id TEXT PRIMARY KEY, target_device_id TEXT NOT NULL, requested_by TEXT NOT NULL,
                action TEXT NOT NULL, args_json TEXT NOT NULL DEFAULT '{}', status TEXT NOT NULL DEFAULT 'queued',
                confirmation INTEGER NOT NULL DEFAULT 0, created REAL NOT NULL, updated REAL NOT NULL, result_json TEXT DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS pcs(
                id TEXT PRIMARY KEY, device_id TEXT NOT NULL UNIQUE, name TEXT NOT NULL,
                mac_address TEXT DEFAULT '', broadcast_address TEXT DEFAULT '255.255.255.255',
                agent_version TEXT DEFAULT '', status TEXT DEFAULT 'unknown', last_seen REAL,
                cpu_percent REAL, ram_percent REAL, storage_percent REAL, network_status TEXT DEFAULT 'unknown',
                wol_enabled INTEGER DEFAULT 0, updated REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS whatsapp_messages(
                id TEXT PRIMARY KEY, provider_message_id TEXT UNIQUE, sender TEXT NOT NULL,
                message_type TEXT NOT NULL, body TEXT DEFAULT '', status TEXT NOT NULL,
                created REAL NOT NULL, detail TEXT DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS pairing_codes(
                code_hash TEXT PRIMARY KEY, owner_device_id TEXT NOT NULL, pc_name TEXT NOT NULL,
                created REAL NOT NULL, expires_at REAL NOT NULL, used INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT);
            """
        )
        columns = {row[1] for row in connection.execute("PRAGMA table_info(events)").fetchall()}
        if "request_id" not in columns:
            connection.execute("ALTER TABLE events ADD COLUMN request_id TEXT DEFAULT ''")
        columns = {row[1] for row in connection.execute("PRAGMA table_info(devices)").fetchall()}
        if "failed_attempts" not in columns:
            connection.execute("ALTER TABLE devices ADD COLUMN failed_attempts INTEGER DEFAULT 0")
        if "failed_window_start" not in columns:
            connection.execute("ALTER TABLE devices ADD COLUMN failed_window_start REAL DEFAULT 0")
        connection.commit()


def audit(source: str, ip: str, event: str, detail: str = "", req_id: str = "") -> None:
    try:
        with closing(database()) as connection:
            connection.execute(
                "INSERT INTO events(ts,source,ip,event,detail,request_id) VALUES(?,?,?,?,?,?)",
                (now(), safe_detail(source, 128), safe_detail(ip, 128), safe_detail(event, 128), safe_detail(detail), safe_detail(req_id, 128)),
            )
            connection.commit()
    except sqlite3.Error:
        pass


def api_error(request: Request, code: str, message: str, status_code: int, extra_headers: dict[str, str] | None = None) -> JSONResponse:
    headers = {"X-Request-ID": request_id(request)}
    if extra_headers:
        headers.update(extra_headers)
    return JSONResponse(status_code=status_code, content={"error": {"code": code, "message": message}, "request_id": request_id(request)}, headers=headers)


def raise_api(code: str, message: str, status_code: int) -> None:
    raise HTTPException(status_code=status_code, detail={"code": code, "message": message})


def enforce_rate_limit(request: Request, key_suffix: str, limit: int | None = None) -> None:
    allowed, retry_after = limiter.allow(f"{client_ip(request)}:{key_suffix}", RATE_LIMIT_PER_MINUTE if limit is None else limit)
    if not allowed:
        audit("rate_limiter", client_ip(request), "rate_limited", key_suffix, request_id(request))
        raise HTTPException(status_code=429, detail={"code": "rate_limited", "message": "Too many requests. Try again later."}, headers={"Retry-After": str(retry_after)})


def require_enrollment(request: Request, supplied: str) -> None:
    if ENROLLMENT_SECRET and not hmac.compare_digest(ENROLLMENT_SECRET, supplied or ""):
        audit("enrollment", client_ip(request), "registration_denied", "invalid enrollment secret", request_id(request))
        raise_api("enrollment_required", "A valid enrollment secret is required.", 401)


def find_device(device_id: str) -> sqlite3.Row | None:
    with closing(database()) as connection:
        return connection.execute("SELECT * FROM devices WHERE id=?", (device_id,)).fetchone()


def record_auth_failure(device_id: str, ip: str, req_id: str, detail: str) -> None:
    with closing(database()) as connection:
        row = connection.execute("SELECT failed_attempts,failed_window_start FROM devices WHERE id=?", (device_id,)).fetchone()
        if not row:
            audit(device_id, ip, "auth_failed", detail, req_id)
            return
        start = float(row["failed_window_start"] or 0)
        attempts = int(row["failed_attempts"] or 0)
        if start <= 0 or start < now() - 300:
            start, attempts = now(), 0
        attempts += 1
        blocked = now() + BLOCK_SECONDS if attempts >= AUTH_FAILURE_LIMIT else 0
        connection.execute("UPDATE devices SET failed_attempts=?,failed_window_start=?,blocked_until=? WHERE id=?", (attempts, start, blocked, device_id))
        connection.commit()
    audit(device_id, ip, "auth_failed", detail, req_id)


def authenticate(request: Request, device_id: str | None, api_key: str, session_token: str) -> str:
    resolved = device_id or ""
    if session_token:
        with closing(database()) as connection:
            row = connection.execute("SELECT device_id FROM sessions WHERE token_hash=? AND revoked=0 AND expires_at>?", (hash_credential(session_token), now())).fetchone()
        if not row:
            audit("unknown", client_ip(request), "auth_failed", "invalid session", request_id(request))
            raise_api("invalid_authentication", "Authentication failed.", 401)
        resolved = row["device_id"]
    if not resolved:
        raise_api("missing_device_id", "X-Device-ID is required.", 401)
    row = find_device(resolved)
    if not row:
        record_auth_failure(resolved, client_ip(request), request_id(request), "unknown device")
        raise_api("invalid_authentication", "Authentication failed.", 401)
    if row["blocked_until"] and float(row["blocked_until"]) > now():
        raise_api("device_blocked", "This device is temporarily blocked.", 403)
    if not session_token and (not api_key or not hmac.compare_digest(row["key_hash"], hash_credential(api_key))):
        record_auth_failure(resolved, client_ip(request), request_id(request), "invalid credential")
        raise_api("invalid_authentication", "Authentication failed.", 401)
    with closing(database()) as connection:
        connection.execute("UPDATE devices SET last_seen=?,failed_attempts=0,failed_window_start=0 WHERE id=?", (now(), resolved))
        connection.commit()
    return resolved


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class RegisterRequest(StrictModel):
    device_id: str = Field(min_length=1, max_length=128)
    name: str = Field(min_length=1, max_length=100)


class SessionRequest(StrictModel):
    device_id: str | None = Field(default=None, min_length=1, max_length=128)


class ChatRequest(StrictModel):
    message: str = Field(min_length=1, max_length=8_000)
    conversation_id: str = Field(default_factory=lambda: str(uuid.uuid4()), min_length=1, max_length=128)


class CommandRequest(StrictModel):
    device_id: str = Field(min_length=1, max_length=128)
    action: str = Field(min_length=1, max_length=64)
    args: dict[str, Any] = Field(default_factory=dict)
    confirmation: bool = False


class RevokeDeviceRequest(StrictModel):
    device_id: str = Field(min_length=1, max_length=128)
    confirmation: bool = False


class AgentHeartbeatRequest(StrictModel):
    agent_version: str = Field(default="unknown", max_length=64)
    pc_name: str = Field(default="Windows PC", max_length=100)
    mac_address: str = Field(default="", max_length=32)
    broadcast_address: str = Field(default="255.255.255.255", max_length=64)
    cpu_percent: float | None = Field(default=None, ge=0, le=100)
    ram_percent: float | None = Field(default=None, ge=0, le=100)
    storage_percent: float | None = Field(default=None, ge=0, le=100)
    network_status: str = Field(default="unknown", max_length=32)


class CommandResultRequest(StrictModel):
    ok: bool
    result: dict[str, Any] = Field(default_factory=dict)
    error: str = Field(default="", max_length=500)


class PcConfigRequest(StrictModel):
    pc_id: str = Field(min_length=1, max_length=128)
    device_id: str = Field(min_length=1, max_length=128)
    name: str = Field(min_length=1, max_length=100)
    mac_address: str = Field(default="", max_length=32)
    broadcast_address: str = Field(default="255.255.255.255", max_length=64)


class WakeRequest(StrictModel):
    confirmation: bool = False


class WhatsAppSendRequest(StrictModel):
    to: str = Field(min_length=3, max_length=64)
    message: str = Field(min_length=1, max_length=4_000)


class PairingCodeRequest(StrictModel):
    pc_name: str = Field(default="Windows PC", min_length=1, max_length=100)


class PairingClaimRequest(StrictModel):
    code: str = Field(min_length=6, max_length=16)
    device_id: str = Field(min_length=1, max_length=128)
    name: str = Field(min_length=1, max_length=100)


SAFE_ACTIONS = {"heartbeat", "open_app", "notify", "get_status", "pc_status", "cpu", "ram", "storage", "network", "launch_browser", "obs_start", "obs_stop", "minecraft_status"}
DANGEROUS_ACTIONS = {"shutdown", "restart", "sleep_pc", "lock_pc", "delete_file", "run_command"}


async def call_ai_provider(message: str, conversation_id: str, req_id: str) -> str:
    if not AI_API_KEY or not AI_BASE_URL or not AI_MODEL:
        raise ProviderNotConfigured()
    endpoint = AI_BASE_URL if AI_BASE_URL.endswith("/chat/completions") else f"{AI_BASE_URL}/chat/completions"
    payload = {"model": AI_MODEL, "messages": [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": message}], "max_tokens": AI_MAX_TOKENS}
    headers = {"Authorization": f"Bearer {AI_API_KEY}", "Content-Type": "application/json", "Accept": "application/json", "X-Request-ID": req_id}
    try:
        async with httpx.AsyncClient(timeout=AI_TIMEOUT_SECONDS) as client:
            response = await client.post(endpoint, json=payload, headers=headers)
    except httpx.TimeoutException as exc:
        raise ProviderTimedOut() from exc
    except httpx.RequestError as exc:
        raise ProviderUnavailable() from exc
    if response.status_code in (401, 403):
        audit("ai_provider", "server", "provider_auth_failed", f"status={response.status_code}", req_id)
        raise ProviderRejected()
    if response.status_code >= 500:
        raise ProviderUnavailable()
    if response.status_code < 200 or response.status_code >= 300:
        raise ProviderRejected()
    try:
        reply = response.json()["choices"][0]["message"]["content"]
    except (ValueError, KeyError, IndexError, TypeError) as exc:
        raise ProviderUnavailable() from exc
    if not isinstance(reply, str) or not reply.strip():
        raise ProviderUnavailable()
    return reply.strip()


def persist_message(conversation_id: str, device_id: str, role: str, body: str) -> None:
    timestamp = now()
    with closing(database()) as connection:
        connection.execute("INSERT OR IGNORE INTO conversations(id,owner_device_id,title,created,updated) VALUES(?,?,?,?,?)", (conversation_id, device_id, safe_detail(body, 80) or "Conversation", timestamp, timestamp))
        connection.execute("INSERT INTO messages(id,conversation_id,device_id,role,body,created) VALUES(?,?,?,?,?,?)", (str(uuid.uuid4()), conversation_id, device_id, role, body, timestamp))
        connection.execute("UPDATE conversations SET updated=? WHERE id=?", (timestamp, conversation_id))
        connection.commit()


def validate_mac(value: str) -> str:
    normalized = value.replace("-", ":").lower()
    parts = normalized.split(":")
    if len(parts) != 6 or any(len(part) != 2 for part in parts):
        raise ValueError("A valid MAC address is required.")
    try:
        bytes(int(part, 16) for part in parts)
    except ValueError as exc:
        raise ValueError("A valid MAC address is required.") from exc
    return ":".join(parts)


def validate_broadcast(value: str) -> str:
    candidate = value.strip() or "255.255.255.255"
    try:
        socket.inet_aton(candidate)
    except OSError as exc:
        raise ValueError("A valid IPv4 broadcast address is required.") from exc
    return candidate


def send_wake_on_lan(mac_address: str, broadcast_address: str) -> None:
    packet = b"\xff" * 6 + bytes.fromhex(validate_mac(mac_address).replace(":", "")) * 16
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.sendto(packet, (validate_broadcast(broadcast_address), 9))


async def send_whatsapp_message(to: str, message: str) -> dict[str, Any]:
    if not (WHATSAPP_ACCESS_TOKEN and WHATSAPP_PHONE_NUMBER_ID):
        raise RuntimeError("Official WhatsApp Cloud API credentials are not configured.")
    endpoint = f"https://graph.facebook.com/{WHATSAPP_API_VERSION}/{WHATSAPP_PHONE_NUMBER_ID}/messages"
    async with httpx.AsyncClient(timeout=15) as client:
        response = await client.post(endpoint, headers={"Authorization": f"Bearer {WHATSAPP_ACCESS_TOKEN}", "Content-Type": "application/json"}, json={"messaging_product": "whatsapp", "to": to, "type": "text", "text": {"body": message}})
    if response.status_code < 200 or response.status_code >= 300:
        raise RuntimeError("The official WhatsApp Cloud API rejected the message.")
    return response.json()


@app.middleware("http")
async def request_context(request: Request, call_next: Callable[..., Any]) -> JSONResponse:
    supplied = request.headers.get("X-Request-ID", "").strip()
    request.state.request_id = supplied[:128] if supplied else str(uuid.uuid4())
    try:
        response = await call_next(request)
    except Exception:
        audit("server", client_ip(request), "unhandled_error", request.url.path, request_id(request))
        response = api_error(request, "internal_error", "The server could not complete the request.", 500)
    response.headers["X-Request-ID"] = request_id(request)
    audit("http", client_ip(request), "request", f"{request.method} {request.url.path} status={response.status_code}", request_id(request))
    return response


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException) -> JSONResponse:
    detail = exc.detail if isinstance(exc.detail, dict) else {"code": "request_failed", "message": str(exc.detail)}
    return api_error(request, str(detail.get("code", "request_failed")), str(detail.get("message", "Request failed.")), exc.status_code, exc.headers)


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    fields = [".".join(str(part) for part in error.get("loc", ())) for error in exc.errors()]
    return api_error(request, "malformed_request", "Malformed request" + (f"; check {', '.join(fields[:4])}." if fields else "."), 422)


@app.exception_handler(sqlite3.Error)
async def database_exception_handler(request: Request, exc: sqlite3.Error) -> JSONResponse:
    audit("database", client_ip(request), "database_error", type(exc).__name__, request_id(request))
    return api_error(request, "database_unavailable", "The database could not complete the request.", 503)


async def health_response(request: Request) -> dict[str, Any]:
    db_status = "ok"
    try:
        with closing(database()) as connection:
            connection.execute("SELECT 1").fetchone()
    except sqlite3.Error:
        db_status = "unavailable"
    return {"ok": db_status == "ok", "service": "PlayzAI", "version": API_VERSION, "request_id": request_id(request), "database_status": db_status, "provider_configured": bool(AI_API_KEY and AI_BASE_URL and AI_MODEL), "whatsapp_configured": bool(WHATSAPP_ACCESS_TOKEN and WHATSAPP_PHONE_NUMBER_ID and WHATSAPP_VERIFY_TOKEN), "authenticated_api_enabled": bool(AUTH_SECRET or os.getenv("PLAYZAI_ENV", "development") != "production")}


@app.get("/health")
async def health(request: Request) -> dict[str, Any]: return await health_response(request)


@app.post("/health")
async def health_post(request: Request) -> dict[str, Any]: return await health_response(request)


@app.post("/api/devices/register")
@app.post("/v1/devices/register")
async def register_device(payload: RegisterRequest, request: Request, x_enrollment_secret: str = Header(default="")) -> dict[str, str]:
    enforce_rate_limit(request, "register", AUTH_RATE_LIMIT_PER_MINUTE)
    require_enrollment(request, x_enrollment_secret)
    api_key = secrets.token_urlsafe(32)
    with closing(database()) as connection:
        connection.execute("INSERT OR REPLACE INTO devices(id,name,key_hash,created,last_seen,blocked_until,failed_attempts,failed_window_start) VALUES(?,?,?,?,?,?,0,0)", (payload.device_id, payload.name, hash_credential(api_key), now(), now(), 0))
        connection.commit()
    audit(payload.device_id, client_ip(request), "device_registered", payload.name, request_id(request))
    return {"device_id": payload.device_id, "api_key": api_key, "request_id": request_id(request)}


@app.post("/api/auth/session")
async def create_session(payload: SessionRequest, request: Request, x_device_id: str = Header(default=""), x_api_key: str = Header(default="")) -> dict[str, Any]:
    enforce_rate_limit(request, "session", AUTH_RATE_LIMIT_PER_MINUTE)
    device_id = authenticate(request, payload.device_id or x_device_id, x_api_key, "")
    token = secrets.token_urlsafe(48)
    expires_at = now() + max(60, int(os.getenv("SESSION_TTL_SECONDS", "3600")))
    with closing(database()) as connection:
        connection.execute("INSERT INTO sessions(id,device_id,token_hash,created,expires_at,revoked) VALUES(?,?,?,?,?,0)", (str(uuid.uuid4()), device_id, hash_credential(token), now(), expires_at))
        connection.commit()
    audit(device_id, client_ip(request), "session_created", "session token issued", request_id(request))
    return {"session_token": token, "device_id": device_id, "expires_at": expires_at, "request_id": request_id(request)}


@app.get("/api/auth/status")
async def auth_status(request: Request, x_device_id: str = Header(default=""), x_api_key: str = Header(default=""), x_session_token: str = Header(default="")) -> dict[str, Any]:
    return {"authenticated": True, "device_id": authenticate(request, x_device_id, x_api_key, x_session_token), "request_id": request_id(request)}


@app.get("/v1/devices")
@app.get("/api/devices")
async def list_devices(request: Request, x_device_id: str = Header(default=""), x_api_key: str = Header(default=""), x_session_token: str = Header(default="")) -> dict[str, Any]:
    current = authenticate(request, x_device_id, x_api_key, x_session_token)
    with closing(database()) as connection:
        rows = connection.execute("SELECT d.*,p.status AS pc_status,p.last_seen AS pc_last_seen,p.agent_version,p.cpu_percent,p.ram_percent,p.storage_percent,p.network_status,p.wol_enabled FROM devices d LEFT JOIN pcs p ON p.device_id=d.id ORDER BY d.created ASC").fetchall()
    result = []
    for row in rows:
        last = float(row["pc_last_seen"] or row["last_seen"]) if (row["pc_last_seen"] or row["last_seen"]) else None
        blocked = bool(row["blocked_until"] and float(row["blocked_until"]) > now())
        item: dict[str, Any] = {"device_id": row["id"], "name": row["name"], "status": "blocked" if blocked else (row["pc_status"] or ("online" if last and now() - last <= 120 else "offline")), "last_seen": last, "authenticated": row["id"] == current}
        if row["pc_status"] is not None:
            item.update({"kind": "pc", "agent_version": row["agent_version"], "wake_on_lan": "configured" if row["wol_enabled"] else "not_configured", "metrics": {"cpu_percent": row["cpu_percent"], "ram_percent": row["ram_percent"], "storage_percent": row["storage_percent"], "network_status": row["network_status"]}})
        result.append(item)
    return {"devices": result, "request_id": request_id(request)}


@app.get("/v1/security/events")
@app.get("/api/security/events")
async def security_events(request: Request, x_device_id: str = Header(default=""), x_api_key: str = Header(default=""), x_session_token: str = Header(default="")) -> dict[str, Any]:
    authenticate(request, x_device_id, x_api_key, x_session_token)
    with closing(database()) as connection:
        rows = connection.execute("SELECT id,ts,source,ip,event,detail,request_id FROM events ORDER BY id DESC LIMIT 100").fetchall()
    return {"events": [dict(row) for row in rows], "request_id": request_id(request)}


@app.post("/api/pairing/codes")
async def create_pairing_code(payload: PairingCodeRequest, request: Request, x_device_id: str = Header(default=""), x_api_key: str = Header(default=""), x_session_token: str = Header(default="")) -> dict[str, Any]:
    owner = authenticate(request, x_device_id, x_api_key, x_session_token)
    code = f"{secrets.randbelow(1_000_000):06d}"
    expiry = now() + 600
    with closing(database()) as connection:
        connection.execute("UPDATE pairing_codes SET used=1 WHERE owner_device_id=? AND used=0", (owner,))
        connection.execute("INSERT INTO pairing_codes(code_hash,owner_device_id,pc_name,created,expires_at,used) VALUES(?,?,?,?,?,0)", (hash_credential(code), owner, payload.pc_name, now(), expiry))
        connection.commit()
    audit(owner, client_ip(request), "pairing_code_created", payload.pc_name, request_id(request))
    return {"pairing_code": code, "expires_at": expiry, "request_id": request_id(request)}


@app.post("/api/pairing/claim")
async def claim_pairing(payload: PairingClaimRequest, request: Request) -> dict[str, Any]:
    enforce_rate_limit(request, "pairing_claim", AUTH_RATE_LIMIT_PER_MINUTE)
    with closing(database()) as connection:
        row = connection.execute("SELECT * FROM pairing_codes WHERE code_hash=? AND used=0 AND expires_at>?", (hash_credential(payload.code), now())).fetchone()
        if not row:
            audit("pairing", client_ip(request), "pairing_claim_failed", "invalid or expired code", request_id(request))
            raise_api("invalid_pairing_code", "The pairing code is invalid or expired.", 401)
        api_key = secrets.token_urlsafe(32)
        connection.execute("UPDATE pairing_codes SET used=1 WHERE code_hash=?", (row["code_hash"],))
        connection.execute("INSERT OR REPLACE INTO devices(id,name,key_hash,created,last_seen,blocked_until,failed_attempts,failed_window_start) VALUES(?,?,?,?,?,?,0,0)", (payload.device_id, payload.name, hash_credential(api_key), now(), now(), 0))
        connection.commit()
    audit(row["owner_device_id"], client_ip(request), "device_paired", payload.device_id, request_id(request))
    return {"device_id": payload.device_id, "api_key": api_key, "pc_name": row["pc_name"], "request_id": request_id(request)}


@app.post("/api/pcs")
async def configure_pc(payload: PcConfigRequest, request: Request, x_device_id: str = Header(default=""), x_api_key: str = Header(default=""), x_session_token: str = Header(default="")) -> dict[str, Any]:
    owner = authenticate(request, x_device_id, x_api_key, x_session_token)
    if not find_device(payload.device_id):
        raise_api("unknown_device", "The PC agent device is not registered.", 404)
    try:
        mac = validate_mac(payload.mac_address) if payload.mac_address else ""
        broadcast = validate_broadcast(payload.broadcast_address)
    except ValueError as exc:
        raise_api("invalid_pc_configuration", str(exc), 422)
    with closing(database()) as connection:
        connection.execute("INSERT INTO pcs(id,device_id,name,mac_address,broadcast_address,status,wol_enabled,updated) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(device_id) DO UPDATE SET id=excluded.id,name=excluded.name,mac_address=excluded.mac_address,broadcast_address=excluded.broadcast_address,wol_enabled=excluded.wol_enabled,updated=excluded.updated", (payload.pc_id, payload.device_id, payload.name, mac, broadcast, "unknown", int(bool(mac)), now()))
        connection.commit()
    audit(owner, client_ip(request), "pc_configured", payload.pc_id, request_id(request))
    return {"ok": True, "pc_id": payload.pc_id, "wake_on_lan": "configured" if mac else "not_configured", "request_id": request_id(request)}


@app.get("/api/pcs")
async def list_pcs(request: Request, x_device_id: str = Header(default=""), x_api_key: str = Header(default=""), x_session_token: str = Header(default="")) -> dict[str, Any]:
    authenticate(request, x_device_id, x_api_key, x_session_token)
    with closing(database()) as connection:
        rows = connection.execute("SELECT id,device_id,name,mac_address,broadcast_address,agent_version,status,last_seen,cpu_percent,ram_percent,storage_percent,network_status,wol_enabled FROM pcs ORDER BY name").fetchall()
    return {"pcs": [dict(row) | {"wake_on_lan": "configured" if row["wol_enabled"] else "not_configured"} for row in rows], "request_id": request_id(request)}


@app.post("/api/pcs/{pc_id}/wake")
async def wake_pc(pc_id: str, payload: WakeRequest, request: Request, x_device_id: str = Header(default=""), x_api_key: str = Header(default=""), x_session_token: str = Header(default="")) -> dict[str, Any]:
    owner = authenticate(request, x_device_id, x_api_key, x_session_token)
    if not payload.confirmation:
        return {"ok": False, "requires_confirmation": True, "pc_id": pc_id, "request_id": request_id(request)}
    with closing(database()) as connection:
        row = connection.execute("SELECT * FROM pcs WHERE id=?", (pc_id,)).fetchone()
    if not row:
        raise_api("pc_not_found", "The PC is not configured.", 404)
    if not row["mac_address"]:
        return {"ok": False, "pc_id": pc_id, "wake_on_lan": "not_configured", "message": "Wake-on-LAN is not configured for this PC.", "request_id": request_id(request)}
    try:
        send_wake_on_lan(row["mac_address"], row["broadcast_address"])
    except (OSError, ValueError):
        audit(owner, client_ip(request), "wake_on_lan_failed", pc_id, request_id(request))
        raise_api("wake_on_lan_failed", "The Wake-on-LAN packet could not be sent.", 503)
    audit(owner, client_ip(request), "wake_on_lan_sent", pc_id, request_id(request))
    return {"ok": True, "pc_id": pc_id, "wake_on_lan": "packet_sent", "request_id": request_id(request)}


@app.post("/api/chat")
@app.post("/v1/chat")
async def chat(payload: ChatRequest, request: Request, x_device_id: str = Header(default=""), x_api_key: str = Header(default=""), x_session_token: str = Header(default="")) -> dict[str, str]:
    device_id = authenticate(request, x_device_id, x_api_key, x_session_token)
    enforce_rate_limit(request, f"chat:{device_id}")
    persist_message(payload.conversation_id, device_id, "user", payload.message)
    try:
        reply = await call_ai_provider(payload.message, payload.conversation_id, request_id(request))
    except ProviderNotConfigured:
        audit(device_id, client_ip(request), "chat_failed", "AI provider not configured", request_id(request))
        raise_api("provider_not_configured", "The AI provider is not configured on the backend.", 503)
    except ProviderTimedOut:
        raise_api("provider_timeout", "The AI provider timed out. Try again later.", 504)
    except ProviderRejected:
        raise_api("provider_error", "The AI provider rejected the request.", 502)
    except ProviderUnavailable:
        raise_api("provider_unavailable", "The AI provider is temporarily unavailable.", 503)
    persist_message(payload.conversation_id, device_id, "assistant", reply)
    audit(device_id, client_ip(request), "chat_completed", f"conversation={payload.conversation_id}", request_id(request))
    return {"reply": reply, "conversation_id": payload.conversation_id, "request_id": request_id(request)}


def command_impl(payload: CommandRequest, request: Request, x_device_id: str, x_api_key: str, x_session_token: str) -> dict[str, Any]:
    sender = authenticate(request, x_device_id or payload.device_id, x_api_key, x_session_token)
    enforce_rate_limit(request, f"command:{sender}")
    if payload.action not in SAFE_ACTIONS and not (payload.action in DANGEROUS_ACTIONS and payload.confirmation):
        audit(sender, client_ip(request), "command_denied", payload.action, request_id(request))
        return {"ok": False, "requires_confirmation": True, "action": payload.action, "request_id": request_id(request)}
    if not find_device(payload.device_id):
        raise_api("unknown_device", "The target device is not registered.", 404)
    command_id = str(uuid.uuid4())
    with closing(database()) as connection:
        connection.execute("INSERT INTO commands(id,target_device_id,requested_by,action,args_json,status,confirmation,created,updated) VALUES(?,?,?,?,?,?,?,?,?)", (command_id, payload.device_id, sender, payload.action, json.dumps(payload.args, ensure_ascii=False), "queued", int(payload.confirmation), now(), now()))
        connection.commit()
    audit(sender, client_ip(request), "command_accepted", f"{payload.action} target={payload.device_id}", request_id(request))
    return {"ok": True, "queued": True, "command_id": command_id, "action": payload.action, "request_id": request_id(request)}


@app.post("/v1/command")
@app.post("/api/command")
async def command(payload: CommandRequest, request: Request, x_device_id: str = Header(default=""), x_api_key: str = Header(default=""), x_session_token: str = Header(default="")) -> dict[str, Any]:
    return command_impl(payload, request, x_device_id, x_api_key, x_session_token)


@app.post("/api/agent/heartbeat")
async def agent_heartbeat(payload: AgentHeartbeatRequest, request: Request, x_device_id: str = Header(default=""), x_api_key: str = Header(default=""), x_session_token: str = Header(default="")) -> dict[str, Any]:
    agent_id = authenticate(request, x_device_id, x_api_key, x_session_token)
    try:
        mac = validate_mac(payload.mac_address) if payload.mac_address else ""
        broadcast = validate_broadcast(payload.broadcast_address)
    except ValueError as exc:
        raise_api("invalid_agent_configuration", str(exc), 422)
    timestamp = now()
    with closing(database()) as connection:
        connection.execute("INSERT INTO pcs(id,device_id,name,mac_address,broadcast_address,agent_version,status,last_seen,cpu_percent,ram_percent,storage_percent,network_status,wol_enabled,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(device_id) DO UPDATE SET name=excluded.name,mac_address=excluded.mac_address,broadcast_address=excluded.broadcast_address,agent_version=excluded.agent_version,status='online',last_seen=excluded.last_seen,cpu_percent=excluded.cpu_percent,ram_percent=excluded.ram_percent,storage_percent=excluded.storage_percent,network_status=excluded.network_status,wol_enabled=excluded.wol_enabled,updated=excluded.updated", (str(uuid.uuid4()), agent_id, payload.pc_name, mac, broadcast, payload.agent_version, "online", timestamp, payload.cpu_percent, payload.ram_percent, payload.storage_percent, payload.network_status, int(bool(mac)), timestamp))
        connection.commit()
    return {"ok": True, "device_id": agent_id, "server_time": timestamp, "request_id": request_id(request)}


@app.get("/api/agent/commands")
async def agent_commands(request: Request, x_device_id: str = Header(default=""), x_api_key: str = Header(default=""), x_session_token: str = Header(default=""), limit: int = Query(default=10, ge=1, le=50)) -> dict[str, Any]:
    agent_id = authenticate(request, x_device_id, x_api_key, x_session_token)
    with closing(database()) as connection:
        rows = connection.execute("SELECT * FROM commands WHERE target_device_id=? AND status='queued' ORDER BY created LIMIT ?", (agent_id, limit)).fetchall()
        if rows:
            connection.executemany("UPDATE commands SET status='dispatched',updated=? WHERE id=?", [(now(), row["id"]) for row in rows])
            connection.commit()
    return {"commands": [{"command_id": row["id"], "action": row["action"], "args": json.loads(row["args_json"] or "{}"), "requested_by": row["requested_by"], "created": row["created"]} for row in rows], "request_id": request_id(request)}


@app.post("/api/agent/commands/{command_id}/result")
async def agent_command_result(command_id: str, payload: CommandResultRequest, request: Request, x_device_id: str = Header(default=""), x_api_key: str = Header(default=""), x_session_token: str = Header(default="")) -> dict[str, Any]:
    agent_id = authenticate(request, x_device_id, x_api_key, x_session_token)
    result = dict(payload.result)
    if payload.error:
        result["error"] = payload.error
    with closing(database()) as connection:
        cursor = connection.execute("UPDATE commands SET status=?,updated=?,result_json=? WHERE id=? AND target_device_id=?", ("completed" if payload.ok else "failed", now(), json.dumps(result, ensure_ascii=False), command_id, agent_id))
        connection.commit()
    if cursor.rowcount != 1:
        raise_api("command_not_found", "The command was not assigned to this agent.", 404)
    return {"ok": True, "command_id": command_id, "request_id": request_id(request)}


@app.get("/api/commands")
async def command_history(request: Request, x_device_id: str = Header(default=""), x_api_key: str = Header(default=""), x_session_token: str = Header(default=""), limit: int = Query(default=50, ge=1, le=100)) -> dict[str, Any]:
    requester = authenticate(request, x_device_id, x_api_key, x_session_token)
    with closing(database()) as connection:
        rows = connection.execute("SELECT id,target_device_id,requested_by,action,status,created,updated,result_json FROM commands WHERE requested_by=? OR target_device_id=? ORDER BY created DESC LIMIT ?", (requester, requester, limit)).fetchall()
    return {"commands": [dict(row) for row in rows], "request_id": request_id(request)}


def require_master_key(request: Request, supplied: str) -> None:
    if not MASTER_KEY or not hmac.compare_digest(MASTER_KEY, supplied or ""):
        audit("owner", client_ip(request), "owner_auth_failed", "invalid master key", request_id(request))
        raise_api("invalid_authentication", "Authentication failed.", 401)


@app.post("/api/devices/revoke")
async def revoke_device(payload: RevokeDeviceRequest, request: Request, x_api_key: str = Header(default="")) -> dict[str, Any]:
    require_master_key(request, x_api_key)
    if not payload.confirmation:
        return {"ok": False, "requires_confirmation": True, "device_id": payload.device_id, "request_id": request_id(request)}
    with closing(database()) as connection:
        connection.execute("UPDATE devices SET blocked_until=? WHERE id=?", (now() + BLOCK_SECONDS, payload.device_id))
        connection.execute("UPDATE sessions SET revoked=1 WHERE device_id=?", (payload.device_id,))
        connection.commit()
    audit("owner", client_ip(request), "device_revoked", payload.device_id, request_id(request))
    return {"ok": True, "device_id": payload.device_id, "blocked_for_seconds": BLOCK_SECONDS, "request_id": request_id(request)}


@app.post("/api/security/lockdown")
async def lockdown(request: Request, x_api_key: str = Header(default="")) -> dict[str, Any]:
    require_master_key(request, x_api_key)
    with closing(database()) as connection:
        connection.execute("UPDATE devices SET blocked_until=?", (now() + BLOCK_SECONDS,))
        connection.execute("UPDATE sessions SET revoked=1")
        connection.commit()
    audit("owner", client_ip(request), "lockdown_enabled", "all devices and sessions temporarily blocked", request_id(request))
    return {"ok": True, "blocked_for_seconds": BLOCK_SECONDS, "request_id": request_id(request)}


@app.post("/api/security/unlock")
async def unlock(request: Request, x_api_key: str = Header(default="")) -> dict[str, Any]:
    require_master_key(request, x_api_key)
    with closing(database()) as connection:
        connection.execute("UPDATE devices SET blocked_until=0,failed_attempts=0,failed_window_start=0")
        connection.execute("UPDATE sessions SET revoked=1")
        connection.commit()
    audit("owner", client_ip(request), "lockdown_disabled", "devices unblocked; re-authentication required", request_id(request))
    return {"ok": True, "reauthentication_required": True, "request_id": request_id(request)}


@app.post("/v1/security/panic")
@app.post("/api/security/panic")
async def panic(request: Request, x_api_key: str = Header(default="")) -> dict[str, Any]: return await lockdown(request, x_api_key)


def websocket_device(websocket: WebSocket) -> str | None:
    device_id = websocket.headers.get("x-device-id") or websocket.query_params.get("device_id")
    api_key = websocket.headers.get("x-api-key") or websocket.query_params.get("api_key")
    token = websocket.headers.get("x-session-token") or websocket.query_params.get("session_token")
    resolved = device_id or ""
    if token:
        with closing(database()) as connection:
            row = connection.execute("SELECT device_id FROM sessions WHERE token_hash=? AND revoked=0 AND expires_at>?", (hash_credential(token), now())).fetchone()
        resolved = row["device_id"] if row else ""
    row = find_device(resolved) if resolved else None
    if not row or (row["blocked_until"] and float(row["blocked_until"]) > now()): return None
    if token or (api_key and hmac.compare_digest(row["key_hash"], hash_credential(api_key))): return resolved
    return None


@app.websocket("/ws")
async def realtime_socket(websocket: WebSocket) -> None:
    device_id = websocket_device(websocket)
    if not device_id:
        await websocket.close(code=4401, reason="Authentication failed")
        return
    await websocket.accept()
    try:
        await websocket.send_json({"type": "connected", "device_id": device_id})
        while True:
            incoming = await websocket.receive_json()
            message_type = incoming.get("type") if isinstance(incoming, dict) else ""
            if message_type == "ping":
                await websocket.send_json({"type": "pong", "server_time": now()})
            elif message_type == "subscribe":
                with closing(database()) as connection:
                    rows = connection.execute("SELECT id,device_id,name,status,last_seen,agent_version FROM pcs ORDER BY name").fetchall()
                await websocket.send_json({"type": "device_snapshot", "pcs": [dict(row) for row in rows]})
            else:
                await websocket.send_json({"type": "ack", "accepted": False, "message": "Only ping and subscribe are supported."})
    except WebSocketDisconnect:
        pass


@app.get("/api/whatsapp/status")
async def whatsapp_status(request: Request) -> dict[str, Any]:
    return {"configured": bool(WHATSAPP_ACCESS_TOKEN and WHATSAPP_PHONE_NUMBER_ID and WHATSAPP_VERIFY_TOKEN), "official_cloud_api": True, "voice_transcription": "provider_required", "request_id": request_id(request)}


@app.get("/api/whatsapp/webhook")
async def whatsapp_verify(request: Request, hub_mode: str = Query(default="", alias="hub.mode"), hub_verify_token: str = Query(default="", alias="hub.verify_token"), hub_challenge: str = Query(default="", alias="hub.challenge")) -> Any:
    if hub_mode == "subscribe" and WHATSAPP_VERIFY_TOKEN and hmac.compare_digest(hub_verify_token, WHATSAPP_VERIFY_TOKEN):
        return int(hub_challenge) if hub_challenge.isdigit() else hub_challenge
    raise_api("whatsapp_verification_failed", "Webhook verification failed.", 403)


@app.post("/api/whatsapp/webhook")
async def whatsapp_webhook(request: Request) -> dict[str, Any]:
    raw = await request.body()
    signature = request.headers.get("x-hub-signature-256", "")
    if WHATSAPP_WEBHOOK_SECRET:
        expected = "sha256=" + hmac.new(WHATSAPP_WEBHOOK_SECRET.encode(), raw, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(signature, expected):
            raise_api("invalid_webhook_signature", "Webhook signature validation failed.", 401)
    try:
        payload = json.loads(raw.decode())
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise_api("malformed_request", "The webhook body is not valid JSON.", 422)
    if payload.get("object") != "whatsapp_business_account": return {"accepted": False, "request_id": request_id(request)}
    accepted = 0
    for entry in payload.get("entry", []):
        for change in entry.get("changes", []):
            for message in change.get("value", {}).get("messages", []):
                provider_id, sender, kind = str(message.get("id", "")), str(message.get("from", "")), str(message.get("type", "unknown"))
                body = str(message.get("text", {}).get("body", "")) if kind == "text" else ""
                if not provider_id or not sender: continue
                with closing(database()) as connection:
                    cursor = connection.execute("INSERT OR IGNORE INTO whatsapp_messages(id,provider_message_id,sender,message_type,body,status,created,detail) VALUES(?,?,?,?,?,?,?,?)", (str(uuid.uuid4()), provider_id, sender, kind, body, "received", now(), ""))
                    connection.commit()
                if cursor.rowcount != 1: continue
                accepted += 1
                if kind == "text" and body and AI_API_KEY and AI_BASE_URL and AI_MODEL:
                    try:
                        reply = await call_ai_provider(body, f"whatsapp-{sender}", request_id(request))
                        await send_whatsapp_message(sender, reply)
                        outcome, detail = "responded", "official Cloud API response sent"
                    except Exception:
                        outcome, detail = "failed", "AI/provider delivery unavailable"
                    with closing(database()) as connection:
                        connection.execute("UPDATE whatsapp_messages SET status=?,detail=? WHERE provider_message_id=?", (outcome, detail, provider_id)); connection.commit()
                elif kind != "text":
                    audit("whatsapp", client_ip(request), "media_received", f"type={kind}", request_id(request))
    return {"accepted": True, "messages_accepted": accepted, "request_id": request_id(request)}


@app.post("/api/whatsapp/send")
async def whatsapp_send(payload: WhatsAppSendRequest, request: Request, x_device_id: str = Header(default=""), x_api_key: str = Header(default=""), x_session_token: str = Header(default="")) -> dict[str, Any]:
    sender = authenticate(request, x_device_id, x_api_key, x_session_token)
    try:
        result = await send_whatsapp_message(payload.to, payload.message)
    except RuntimeError as exc:
        raise_api("whatsapp_unavailable", str(exc), 503)
    audit(sender, client_ip(request), "whatsapp_message_sent", payload.to, request_id(request))
    return {"ok": True, "provider_message_id": result.get("messages", [{}])[0].get("id", ""), "request_id": request_id(request)}


init_db()
