import { describe, expect, it, vi } from 'vitest'
import { normalizeBaseUrl, PlayzApi } from './api'

const auth = { baseUrl: 'https://backend.example/', deviceId: 'phone-1', apiKey: 'secret', sessionToken: '' }

describe('dashboard API client', () => {
  it('normalizes a configurable backend URL', () => {
    expect(normalizeBaseUrl('  https://backend.example/// ')).toBe('https://backend.example')
  })

  it('uses the real health route and authenticated headers', async () => {
    const fetchMock = vi.spyOn(globalThis, 'fetch').mockResolvedValue(new Response(JSON.stringify({ ok: true, database_status: 'ok' }), { status: 200 }))
    const api = new PlayzApi(auth)
    await expect(api.health()).resolves.toMatchObject({ ok: true, database_status: 'ok' })
    expect(fetchMock).toHaveBeenCalledWith('https://backend.example/health', expect.objectContaining({ method: 'GET', headers: expect.objectContaining({ 'X-Device-ID': 'phone-1', 'X-API-Key': 'secret' }) }))
    fetchMock.mockRestore()
  })

  it('surfaces structured backend errors without inventing a response', async () => {
    const fetchMock = vi.spyOn(globalThis, 'fetch').mockResolvedValue(new Response(JSON.stringify({ error: { code: 'provider_not_configured', message: 'AI provider is not configured.' } }), { status: 503 }))
    const api = new PlayzApi(auth)
    await expect(api.chat('hello', 'conversation-1')).rejects.toMatchObject({ status: 503, code: 'provider_not_configured', message: 'AI provider is not configured.' })
    fetchMock.mockRestore()
  })

  it('builds an authenticated websocket URL', () => {
    const api = new PlayzApi({ ...auth, sessionToken: 'session-token' })
    const url = new URL(api.websocketUrl())
    expect(url.protocol).toBe('wss:')
    expect(url.pathname).toBe('/ws')
    expect(url.searchParams.get('device_id')).toBe('phone-1')
    expect(url.searchParams.get('session_token')).toBe('session-token')
  })
})
