export type PageKey =
  | 'overview'
  | 'chat'
  | 'devices'
  | 'pc'
  | 'security'
  | 'commands'
  | 'conversations'
  | 'whatsapp'
  | 'audit'
  | 'settings'
  | 'about'

export type Health = {
  ok: boolean
  service?: string
  version?: string
  database_status?: string
  provider_configured?: boolean
  whatsapp_configured?: boolean
  authenticated_api_enabled?: boolean
  request_id?: string
}

export type MetricSet = {
  cpu_percent?: number | null
  ram_percent?: number | null
  storage_percent?: number | null
  network_status?: string | null
}

export type Device = {
  device_id: string
  name: string
  status?: string
  last_seen?: number | null
  authenticated?: boolean
  kind?: string
  agent_version?: string
  metrics?: MetricSet
  wake_on_lan?: string
}

export type Pc = {
  id: string
  device_id: string
  name: string
  mac_address?: string
  broadcast_address?: string
  agent_version?: string
  status?: string
  last_seen?: number | null
  cpu_percent?: number | null
  ram_percent?: number | null
  storage_percent?: number | null
  network_status?: string | null
  wake_on_lan?: string
}

export type SecurityEvent = {
  id: number | string
  ts?: number
  source?: string
  ip?: string
  event?: string
  detail?: string
  request_id?: string
}

export type Command = {
  id?: string
  command_id?: string
  target_device_id?: string
  requested_by?: string
  action?: string
  args?: Record<string, unknown>
  status?: string
  confirmation?: boolean
  created?: number
  updated?: number
  result_json?: string
}

export type WhatsAppStatus = {
  configured?: boolean
  official_cloud_api?: boolean
  voice_transcription?: string
}

export type ChatMessage = {
  id: string
  role: 'user' | 'assistant'
  body: string
  created: number
}

export type Conversation = {
  id: string
  title: string
  created: number
  updated: number
  messages: ChatMessage[]
}

export type AuthState = {
  baseUrl: string
  deviceId: string
  apiKey: string
  sessionToken: string
  expiresAt?: number
}

export type RealtimeState = {
  connected: boolean
  lastMessage?: string
  error?: string
}

export type ApiError = Error & { status?: number; code?: string }
