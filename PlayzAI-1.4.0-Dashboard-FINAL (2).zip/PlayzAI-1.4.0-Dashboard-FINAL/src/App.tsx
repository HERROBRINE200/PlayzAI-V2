import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type React from 'react'
import {
  Activity,
  AlertTriangle,
  Archive,
  ArrowUpRight,
  Bell,
  Bot,
  Check,
  CheckCircle2,
  ChevronRight,
  CircleHelp,
  Clock3,
  Code2,
  Copy,
  Cpu,
  Database,
  FileKey2,
  Gauge,
  Globe2,
  HardDrive,
  LayoutDashboard,
  Lock,
  LogOut,
  Menu,
  MessageSquare,
  Monitor,
  Moon,
  MoreHorizontal,
  Network,
  Phone,
  Plus,
  Power,
  RefreshCw,
  Search,
  Send,
  Server,
  Settings,
  Shield,
  ShieldAlert,
  Smartphone,
  Sparkles,
  Sun,
  Terminal,
  Trash2,
  Unlock,
  UserRound,
  Wifi,
  X,
  Zap,
} from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import { defaultApiBaseUrl, normalizeBaseUrl, PlayzApi } from './api'
import type {
  AuthState,
  ChatMessage,
  Command,
  Conversation,
  Device,
  Health,
  PageKey,
  Pc,
  RealtimeState,
  SecurityEvent,
  WhatsAppStatus,
} from './types'
import './styles.css'

const navItems: { key: PageKey; label: string; icon: LucideIcon; group?: string }[] = [
  { key: 'overview', label: 'Overview', icon: LayoutDashboard },
  { key: 'chat', label: 'AI Chat', icon: MessageSquare },
  { key: 'devices', label: 'Devices', icon: Smartphone, group: 'CONTROL' },
  { key: 'pc', label: 'PC Control', icon: Monitor, group: 'CONTROL' },
  { key: 'security', label: 'Security Center', icon: Shield, group: 'CONTROL' },
  { key: 'commands', label: 'Commands', icon: Terminal, group: 'INSIGHT' },
  { key: 'conversations', label: 'Conversations', icon: Archive, group: 'INSIGHT' },
  { key: 'whatsapp', label: 'WhatsApp', icon: Phone, group: 'INSIGHT' },
  { key: 'audit', label: 'Activity / Audit', icon: Activity, group: 'INSIGHT' },
  { key: 'settings', label: 'Settings', icon: Settings, group: 'SYSTEM' },
  { key: 'about', label: 'About PlayzAI', icon: CircleHelp, group: 'SYSTEM' },
]

function readSavedAuth(): AuthState | null {
  try {
    const raw = sessionStorage.getItem('playzai.dashboard.auth')
    return raw ? JSON.parse(raw) as AuthState : null
  } catch { return null }
}

function saveAuth(auth: AuthState | null) {
  if (auth) sessionStorage.setItem('playzai.dashboard.auth', JSON.stringify(auth))
  else sessionStorage.removeItem('playzai.dashboard.auth')
}

function readConversations(): Conversation[] {
  try {
    const raw = sessionStorage.getItem('playzai.dashboard.conversations')
    return raw ? JSON.parse(raw) as Conversation[] : []
  } catch { return [] }
}

function saveConversations(value: Conversation[]) {
  sessionStorage.setItem('playzai.dashboard.conversations', JSON.stringify(value))
}

function formatTime(value?: number | null) {
  if (!value) return 'Not available'
  const date = new Date(value < 10_000_000_000 ? value * 1000 : value)
  if (Number.isNaN(date.getTime())) return 'Not available'
  return date.toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
}

function relativeTime(value?: number | null) {
  if (!value) return 'Not available'
  const ms = value < 10_000_000_000 ? value * 1000 : value
  const seconds = Math.max(0, Math.floor((Date.now() - ms) / 1000))
  if (seconds < 60) return `${seconds}s ago`
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`
  return `${Math.floor(seconds / 86400)}d ago`
}

function statusKey(value?: string | boolean | null) {
  if (value === true) return 'online'
  const normalized = String(value ?? '').toLowerCase()
  if (['online', 'ok', 'configured', 'protected', 'success', 'completed', 'connected'].includes(normalized)) return 'online'
  if (['blocked', 'failed', 'error', 'locked', 'offline'].includes(normalized)) return normalized === 'offline' ? 'offline' : 'danger'
  if (['pending', 'unknown', 'not_configured', 'unavailable', 'queued', 'dispatched'].includes(normalized)) return 'pending'
  return 'neutral'
}

function statusLabel(value?: string | boolean | null) {
  if (value === true) return 'Online'
  if (value === false) return 'Offline'
  const normalized = String(value ?? '').toLowerCase()
  const map: Record<string, string> = { online: 'Online', offline: 'Offline', ok: 'Operational', configured: 'Configured', not_configured: 'Not configured', unknown: 'Unknown', blocked: 'Blocked', queued: 'Queued', dispatched: 'Dispatched', completed: 'Success', failed: 'Failed', danger: 'Action required' }
  return map[normalized] ?? (value ? String(value) : 'Unavailable')
}

function MetricValue({ value, suffix = '' }: { value?: number | null; suffix?: string }) {
  return <span>{typeof value === 'number' ? `${Math.round(value * 10) / 10}${suffix}` : 'Unavailable'}</span>
}

function Logo({ compact = false }: { compact?: boolean }) {
  return <div className={`brand ${compact ? 'brand-compact' : ''}`}>
    <div className="brand-mark"><Sparkles size={19} strokeWidth={2.4} /></div>
    {!compact && <div><strong>Playz<span>AI</span></strong><small>CONTROL CENTER</small></div>}
  </div>
}

function StatusPill({ value, label, pulse = false }: { value?: string | boolean | null; label?: string; pulse?: boolean }) {
  const key = statusKey(value)
  return <span className={`status-pill ${key} ${pulse ? 'pulse' : ''}`}><i />{label ?? statusLabel(value)}</span>
}

function Toast({ message, onClose }: { message: { text: string; kind: 'success' | 'error' | 'info' }; onClose: () => void }) {
  return <div className={`toast toast-${message.kind}`}><span className="toast-icon">{message.kind === 'success' ? <Check size={16} /> : message.kind === 'error' ? <AlertTriangle size={16} /> : <Bell size={16} />}</span><span>{message.text}</span><button className="icon-button mini" onClick={onClose} aria-label="Close notification"><X size={14} /></button></div>
}

function AuthScreen({ onAuthenticated }: { onAuthenticated: (auth: AuthState) => void }) {
  const [baseUrl, setBaseUrl] = useState(defaultApiBaseUrl())
  const [deviceId, setDeviceId] = useState('')
  const [apiKey, setApiKey] = useState('')
  const [remember, setRemember] = useState(true)
  const [working, setWorking] = useState(false)
  const [error, setError] = useState('')

  const connect = async (event: React.FormEvent) => {
    event.preventDefault(); setError(''); setWorking(true)
    try {
      const initial: AuthState = { baseUrl: normalizeBaseUrl(baseUrl), deviceId: deviceId.trim(), apiKey: apiKey.trim(), sessionToken: '' }
      if (!initial.baseUrl || !initial.deviceId || !initial.apiKey) throw new Error('Backend URL, device ID, and API key are required.')
      const api = new PlayzApi(initial)
      const health = await api.health()
      if (!health.ok) throw new Error(`Backend is not healthy (${health.database_status ?? 'unavailable'}).`)
      let next = initial
      try {
        const session = await api.createSession()
        next = { ...initial, sessionToken: session.session_token, expiresAt: session.expires_at }
      } catch {
        await api.authStatus()
      }
      const authenticated = new PlayzApi(next)
      await authenticated.authStatus()
      if (!remember) sessionStorage.removeItem('playzai.dashboard.auth')
      onAuthenticated(next)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to connect to the backend.')
    } finally { setWorking(false) }
  }

  return <div className="auth-layout">
    <div className="auth-orbit orbit-one" /><div className="auth-orbit orbit-two" />
    <div className="auth-left"><Logo /><div className="auth-hero"><span className="eyebrow"><Zap size={14} /> SECURE CONTROL LAYER</span><h1>Your intelligence,<br /><em>under control.</em></h1><p>PlayzAI brings your AI, devices, Windows PC, and security operations into one calm, precise command center.</p><div className="hero-points"><span><CheckCircle2 size={16} /> Truthful live states</span><span><Shield size={16} /> Authenticated by design</span><span><Activity size={16} /> Backend telemetry</span></div></div><div className="auth-foot">PLAYZAI 1.4.0 <span>•</span> PRIVATE CONTROL SYSTEM</div></div>
    <div className="auth-panel"><div className="auth-panel-inner"><div className="mobile-brand"><Logo /></div><div className="auth-kicker">WELCOME BACK</div><h2>Connect to your<br /><span>control center.</span></h2><p className="muted">Use the device credential issued by your PlayzAI backend. No frontend-only login is used.</p><form onSubmit={connect} className="auth-form">
      <label>Backend URL<input value={baseUrl} onChange={e => setBaseUrl(e.target.value)} placeholder="https://your-backend.example" autoComplete="url" /></label>
      <label>Device ID<input value={deviceId} onChange={e => setDeviceId(e.target.value)} placeholder="owner-phone" autoComplete="username" /></label>
      <label>API key<input value={apiKey} onChange={e => setApiKey(e.target.value)} placeholder="Paste device API key" type="password" autoComplete="current-password" /></label>
      {error && <div className="form-error"><AlertTriangle size={16} />{error}</div>}
      <label className="check-label"><input type="checkbox" checked={remember} onChange={e => setRemember(e.target.checked)} /><span>Keep this session in this browser tab</span></label>
      <button className="button primary wide" disabled={working}>{working ? <><RefreshCw className="spin" size={17} /> Verifying connection...</> : <><ArrowUpRight size={17} /> Enter dashboard</>}</button>
    </form><div className="auth-note"><Lock size={14} /><span>Credentials stay in session memory and are never bundled into the build.</span></div></div></div>
  </div>
}

function Panel({ title, subtitle, action, children, className = '' }: { title: string; subtitle?: string; action?: React.ReactNode; children: React.ReactNode; className?: string }) {
  return <section className={`panel ${className}`}><div className="panel-head"><div><h3>{title}</h3>{subtitle && <p>{subtitle}</p>}</div>{action}</div>{children}</section>
}

function StatCard({ label, value, detail, icon: Icon, tone = 'violet', status }: { label: string; value: string; detail?: string; icon: typeof Activity; tone?: string; status?: string | boolean }) {
  return <div className={`stat-card tone-${tone}`}><div className="stat-top"><span className="stat-label">{label}</span><span className="stat-icon"><Icon size={18} /></span></div><div className="stat-value">{value}</div><div className="stat-bottom">{status !== undefined ? <StatusPill value={status} label={detail} /> : <span>{detail}</span>}</div></div>
}

function EmptyState({ icon: Icon = CircleHelp, title, body, action }: { icon?: typeof CircleHelp; title: string; body: string; action?: React.ReactNode }) {
  return <div className="empty-state"><div className="empty-icon"><Icon size={22} /></div><strong>{title}</strong><p>{body}</p>{action}</div>
}

function SectionTitle({ eyebrow, title, body, action }: { eyebrow?: string; title: string; body?: string; action?: React.ReactNode }) {
  return <div className="section-title"><div>{eyebrow && <span className="eyebrow">{eyebrow}</span>}<h1>{title}</h1>{body && <p>{body}</p>}</div>{action}</div>
}

function ProgressBar({ value, tone = 'violet' }: { value?: number | null; tone?: string }) {
  return <div className={`progress ${tone}`}><span style={{ width: typeof value === 'number' ? `${Math.min(100, Math.max(0, value))}%` : '0%' }} /></div>
}

function Dashboard({ auth, onLogout }: { auth: AuthState; onLogout: () => void }) {
  const api = useMemo(() => new PlayzApi(auth), [auth])
  const [page, setPage] = useState<PageKey>('overview')
  const [drawer, setDrawer] = useState(false)
  const [health, setHealth] = useState<Health | null>(null)
  const [devices, setDevices] = useState<Device[]>([])
  const [pcs, setPcs] = useState<Pc[]>([])
  const [events, setEvents] = useState<SecurityEvent[]>([])
  const [commands, setCommands] = useState<Command[]>([])
  const [whatsapp, setWhatsapp] = useState<WhatsAppStatus | null>(null)
  const [latency, setLatency] = useState<number | null>(null)
  const [refreshing, setRefreshing] = useState(false)
  const [loadError, setLoadError] = useState('')
  const [realtime, setRealtime] = useState<RealtimeState>({ connected: false })
  const [toast, setToast] = useState<{ text: string; kind: 'success' | 'error' | 'info' } | null>(null)
  const [theme, setTheme] = useState(() => sessionStorage.getItem('playzai.dashboard.theme') ?? 'dark')
  const [masterKey, setMasterKey] = useState('')
  const [conversations, setConversations] = useState<Conversation[]>(readConversations)
  const [notificationCount, setNotificationCount] = useState(0)
  const wsRef = useRef<WebSocket | null>(null)

  const notify = useCallback((text: string, kind: 'success' | 'error' | 'info' = 'info') => {
    setToast({ text, kind }); setNotificationCount(value => value + (kind === 'error' ? 1 : 0))
  }, [])

  const logout = useCallback(() => { wsRef.current?.close(); saveAuth(null); onLogout() }, [onLogout])

  const refresh = useCallback(async (quiet = false) => {
    if (!quiet) setRefreshing(true)
    setLoadError('')
    const started = performance.now()
    try {
      const healthResult = await api.health()
      setHealth(healthResult); setLatency(Math.round(performance.now() - started))
      const authResult = await api.authStatus()
      if (!authResult.authenticated) throw new Error('The backend did not authenticate this session.')
      const results = await Promise.allSettled([api.devices(), api.pcs(), api.securityEvents(), api.commands(), api.whatsappStatus()])
      const [deviceResult, pcResult, eventResult, commandResult, whatsResult] = results
      if (deviceResult.status === 'fulfilled') setDevices(deviceResult.value.devices ?? [])
      if (pcResult.status === 'fulfilled') setPcs(pcResult.value.pcs ?? [])
      if (eventResult.status === 'fulfilled') setEvents(eventResult.value.events ?? [])
      if (commandResult.status === 'fulfilled') setCommands(commandResult.value.commands ?? [])
      if (whatsResult.status === 'fulfilled') setWhatsapp(whatsResult.value)
      const failed = results.filter(result => result.status === 'rejected').length
      if (failed) setLoadError(`${failed} dashboard data source${failed > 1 ? 's' : ''} unavailable. Showing only confirmed backend data.`)
    } catch (error) {
      const status = (error as { status?: number }).status
      if (status === 401 || status === 403) { notify('Your backend session has expired. Please connect again.', 'error'); logout(); return }
      setLoadError(error instanceof Error ? error.message : 'The backend could not be reached.')
    } finally { setRefreshing(false) }
  }, [api, logout, notify])

  useEffect(() => { document.documentElement.dataset.theme = theme; sessionStorage.setItem('playzai.dashboard.theme', theme) }, [theme])
  useEffect(() => { void refresh(); const timer = window.setInterval(() => void refresh(true), 30_000); return () => window.clearInterval(timer) }, [refresh])
  useEffect(() => {
    let cancelled = false
    let retryTimer: number | undefined
    let pingTimer: number | undefined
    let attempt = 0
    const connect = () => {
      if (cancelled) return
      try {
        const ws = new WebSocket(api.websocketUrl()); wsRef.current = ws
        ws.onopen = () => { attempt = 0; setRealtime({ connected: true, lastMessage: 'Connected' }); ws.send(JSON.stringify({ type: 'subscribe' })); pingTimer = window.setInterval(() => { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: 'ping' })) }, 30_000) }
        ws.onmessage = event => { try { const message = JSON.parse(event.data) as { type?: string; pcs?: Pc[] }; setRealtime(state => ({ ...state, connected: true, lastMessage: message.type ?? 'Update' })); if (message.type === 'device_snapshot' && message.pcs) setPcs(message.pcs) } catch { /* ignore malformed realtime messages */ } }
        ws.onerror = () => setRealtime(state => ({ ...state, error: 'Realtime channel unavailable' }))
        ws.onclose = () => { if (pingTimer) window.clearInterval(pingTimer); setRealtime({ connected: false, lastMessage: 'Reconnecting' }); if (!cancelled) { attempt += 1; retryTimer = window.setTimeout(connect, Math.min(15_000, 1_500 * 2 ** Math.min(attempt, 3))) } }
      } catch { retryTimer = window.setTimeout(connect, 8_000) }
    }
    connect()
    return () => { cancelled = true; if (retryTimer) window.clearTimeout(retryTimer); if (pingTimer) window.clearInterval(pingTimer); wsRef.current?.close() }
  }, [api])

  const selected = navItems.find(item => item.key === page)
  const pcOnline = pcs.find(pc => statusKey(pc.status) === 'online')
  const go = (target: PageKey) => { setPage(target); setDrawer(false) }
  const context = { api, auth, health, devices, pcs, events, commands, whatsapp, latency, conversations, setConversations, masterKey, setMasterKey, notify, refresh, go, realtime }

  return <div className="app-shell">
    <aside className={`sidebar ${drawer ? 'open' : ''}`}><div className="sidebar-head"><Logo /><button className="icon-button mobile-close" onClick={() => setDrawer(false)} aria-label="Close navigation"><X size={19} /></button></div><div className="workspace-chip"><span className="workspace-avatar"><Sparkles size={15} /></span><span><strong>Control space</strong><small>Personal instance</small></span><ChevronRight size={14} /></div><nav>{navItems.map((item, index) => <div key={item.key}>{item.group && (index === 0 || navItems[index - 1]?.group !== item.group) && <span className="nav-group">{item.group}</span>}<button className={`nav-item ${page === item.key ? 'active' : ''}`} onClick={() => go(item.key)}><item.icon size={18} strokeWidth={page === item.key ? 2.4 : 1.9} /><span>{item.label}</span>{item.key === 'security' && events.some(event => event.event?.includes('failed')) && <i className="nav-alert" />}</button></div>)}</nav><div className="sidebar-bottom"><div className="connection-mini"><span className={`connection-dot ${health?.ok ? 'online' : 'offline'}`} /><div><strong>{health?.ok ? 'Backend healthy' : 'Backend unknown'}</strong><small>{realtime.connected ? 'Realtime linked' : 'Polling mode'}</small></div></div><button className="nav-item" onClick={() => go('about')}><CircleHelp size={18} /><span>Help & docs</span></button><div className="sidebar-version">PLAYZAI <span>1.4.0</span></div></div></aside>
    {drawer && <button className="drawer-backdrop" onClick={() => setDrawer(false)} aria-label="Close menu" />}
    <main className="main-area"><header className="topbar"><button className="icon-button mobile-menu" onClick={() => setDrawer(true)} aria-label="Open navigation"><Menu size={21} /></button><div className="breadcrumb"><span>Workspace</span><ChevronRight size={14} /><strong>{selected?.label}</strong></div><div className="top-actions"><div className="top-live"><span className={`connection-dot ${health?.ok ? 'online' : 'offline'}`} />{health?.ok ? 'Backend online' : 'Backend offline'}</div><button className="icon-button notification-button" onClick={() => { setNotificationCount(0); notify('Notifications are sourced from backend activity. No new push feed is configured.', 'info') }} aria-label="Notifications"><Bell size={18} />{notificationCount > 0 && <b>{notificationCount}</b>}</button><button className="theme-toggle" onClick={() => setTheme(value => value === 'dark' ? 'light' : 'dark')} aria-label="Toggle theme">{theme === 'dark' ? <Sun size={17} /> : <Moon size={17} />}</button><div className="profile-chip"><span className="profile-avatar"><UserRound size={16} /></span><span className="profile-copy"><strong>{auth.deviceId}</strong><small>Authenticated device</small></span><button className="icon-button mini" onClick={logout} title="Log out" aria-label="Log out"><LogOut size={15} /></button></div></div></header><div className="page-wrap">{loadError && <div className="data-warning"><AlertTriangle size={16} /><span>{loadError}</span><button onClick={() => void refresh()}>Retry</button></div>}{refreshing && <div className="refresh-line"><span />Syncing confirmed backend state...</div>}{page === 'overview' && <Overview {...context} pcOnline={pcOnline} />}{page === 'chat' && <ChatPage {...context} />}{page === 'devices' && <DevicesPage {...context} />}{page === 'pc' && <PcControlPage {...context} />}{page === 'security' && <SecurityPage {...context} />}{page === 'commands' && <CommandsPage {...context} />}{page === 'conversations' && <ConversationsPage {...context} />}{page === 'whatsapp' && <WhatsAppPage {...context} />}{page === 'audit' && <AuditPage {...context} />}{page === 'settings' && <SettingsPage {...context} theme={theme} setTheme={setTheme} />}{page === 'about' && <AboutPage go={go} />}</div></main>{toast && <Toast message={toast} onClose={() => setToast(null)} />}</div>
}

type Context = { api: PlayzApi; auth: AuthState; health: Health | null; devices: Device[]; pcs: Pc[]; events: SecurityEvent[]; commands: Command[]; whatsapp: WhatsAppStatus | null; latency: number | null; conversations: Conversation[]; setConversations: React.Dispatch<React.SetStateAction<Conversation[]>>; masterKey: string; setMasterKey: (value: string) => void; notify: (text: string, kind?: 'success' | 'error' | 'info') => void; refresh: (quiet?: boolean) => Promise<void>; go: (page: PageKey) => void; realtime: RealtimeState }

function Overview({ pcOnline, ...ctx }: Context & { pcOnline?: Pc }) {
  const { health, devices, pcs, events, commands, whatsapp, latency, realtime, go } = ctx
  const phone = devices.find(device => device.kind !== 'pc' && device.device_id !== pcOnline?.device_id)
  const locked = devices.some(device => statusKey(device.status) === 'danger')
  return <><SectionTitle eyebrow="SYSTEM OVERVIEW" title="Good to see you." body="A truthful readout of your PlayzAI control plane." action={<button className="button subtle" onClick={() => void ctx.refresh()}><RefreshCw size={16} /> Refresh state</button>} /><div className="hero-strip"><div><span className="eyebrow"><span className="live-dot" /> LIVE CONTROL PLANE</span><h2>Everything important,<br /><em>in one calm view.</em></h2><p>Real backend evidence only. Missing configuration stays visible instead of becoming a guess.</p></div><div className="hero-orb"><div className="orb-core"><Sparkles size={28} /></div><div className="orb-ring ring-a" /><div className="orb-ring ring-b" /></div></div><div className="stats-grid"><StatCard label="Backend" value={health?.ok ? 'Operational' : 'Unavailable'} detail={health?.ok ? 'API responding' : 'Check connection'} icon={Server} tone="violet" status={health?.ok} /><StatCard label="AI provider" value={health?.provider_configured ? 'Configured' : 'Not configured'} detail={health?.provider_configured ? 'Provider ready' : 'External setup required'} icon={Bot} tone="blue" status={health?.provider_configured} /><StatCard label="Database" value={health?.database_status === 'ok' ? 'Healthy' : (health?.database_status ?? 'Unavailable')} detail="Backend-reported state" icon={Database} tone="green" status={health?.database_status === 'ok'} /><StatCard label="WhatsApp" value={whatsapp?.configured ? 'Configured' : 'Not configured'} detail={whatsapp?.official_cloud_api ? 'Official Cloud API boundary' : 'Unavailable'} icon={Phone} tone="amber" status={whatsapp?.configured} /></div><div className="overview-grid"><Panel title="System health" subtitle="Measured from the last sync" className="health-panel"><div className="health-row"><div className="health-icon"><Gauge size={18} /></div><div className="health-copy"><strong>API latency</strong><span>{latency !== null ? `${latency} ms` : 'Unavailable'}</span></div><div className="health-meter"><ProgressBar value={latency !== null ? Math.max(8, 100 - latency / 3) : 0} tone="blue" /></div></div><div className="health-row"><div className="health-icon"><Wifi size={18} /></div><div className="health-copy"><strong>Realtime channel</strong><span>{realtime.connected ? realtime.lastMessage ?? 'Connected' : 'Reconnecting / unavailable'}</span></div><StatusPill value={realtime.connected} /></div><div className="health-row"><div className="health-icon"><Smartphone size={18} /></div><div className="health-copy"><strong>Connected devices</strong><span>{devices.length ? `${devices.length} registered` : 'Unavailable'}</span></div><span className="health-number">{devices.length || '—'}</span></div><div className="health-row"><div className="health-icon"><Activity size={18} /></div><div className="health-copy"><strong>Queued activity</strong><span>{commands.length ? 'Command history available' : 'No command history returned'}</span></div><span className="health-number">{commands.length || '—'}</span></div></Panel><Panel title="Windows PC" subtitle="Authenticated agent telemetry" action={<button className="text-button" onClick={() => go('pc')}>Open control <ArrowUpRight size={14} /></button>} className="pc-overview"><div className="pc-summary"><div className="device-avatar pc"><Monitor size={22} /></div><div><h4>{pcOnline?.name ?? pcs[0]?.name ?? 'Windows PC'}</h4><span>{pcOnline ? `Last heartbeat ${relativeTime(pcOnline.last_seen)}` : 'No confirmed online heartbeat'}</span></div><StatusPill value={pcOnline?.status ?? 'unknown'} /></div>{pcOnline ? <div className="metric-grid"><MiniMetric icon={Cpu} label="CPU" value={pcOnline.cpu_percent} /><MiniMetric icon={Activity} label="RAM" value={pcOnline.ram_percent} /><MiniMetric icon={HardDrive} label="Storage" value={pcOnline.storage_percent} /><MiniMetric icon={Network} label="Network" text={pcOnline.network_status ?? 'Unavailable'} /></div> : <EmptyState icon={Monitor} title="PC state unavailable" body="A paired agent heartbeat is required before an online state can be shown." action={<button className="button small" onClick={() => go('devices')}>Pair a device</button>} />}</Panel></div><Panel title="Recent activity" subtitle="Latest events returned by the backend" action={<button className="text-button" onClick={() => go('audit')}>View audit log <ArrowUpRight size={14} /></button>}><ActivityList events={events.slice(0, 5)} commands={commands.slice(0, 2)} /></Panel><div className="overview-footer-cards"><div className="small-callout"><div className="callout-icon"><Shield size={17} /></div><div><strong>{locked ? 'Action required' : 'Security center'}</strong><span>{locked ? 'A blocked device state is present.' : 'Review authenticated events and lockdown controls.'}</span></div><button onClick={() => go('security')}><ArrowUpRight size={15} /></button></div><div className="small-callout"><div className="callout-icon blue"><MessageSquare size={17} /></div><div><strong>{phone?.name ?? 'Your Android device'}</strong><span>{phone ? `${statusLabel(phone.status)} · ${relativeTime(phone.last_seen)}` : 'Device evidence unavailable.'}</span></div><button onClick={() => go('devices')}><ArrowUpRight size={15} /></button></div></div></>
}

function MiniMetric({ icon: Icon, label, value, text }: { icon: typeof Cpu; label: string; value?: number | null; text?: string }) { return <div className="mini-metric"><Icon size={14} /><span>{label}</span><strong>{text ?? <MetricValue value={value} suffix="%" />}</strong></div> }

function ActivityList({ events, commands }: { events: SecurityEvent[]; commands: Command[] }) {
  const items = [...events.map(event => ({ key: `e-${event.id}`, title: event.event ?? 'Backend event', detail: event.source ?? 'Backend', time: event.ts, status: event.event?.includes('failed') ? 'danger' : 'online' })), ...commands.map(command => ({ key: `c-${command.id ?? command.command_id}`, title: `Command · ${command.action ?? 'unknown'}`, detail: command.target_device_id ?? 'Device unavailable', time: command.created, status: statusKey(command.status) }))].sort((a, b) => (b.time ?? 0) - (a.time ?? 0)).slice(0, 6)
  if (!items.length) return <EmptyState icon={Activity} title="No activity returned" body="The backend has not returned recent activity for this session." />
  return <div className="activity-list">{items.map(item => <div className="activity-row" key={item.key}><span className={`activity-dot ${item.status}`} /><div className="activity-body"><strong>{item.title}</strong><span>{item.detail}</span></div><time>{relativeTime(item.time)}</time></div>)}</div>
}

function ChatPage({ ...ctx }: Context) {
  const { api, conversations, setConversations, notify } = ctx
  const [selectedId, setSelectedId] = useState(conversations[0]?.id ?? '')
  const [draft, setDraft] = useState('')
  const [sending, setSending] = useState(false)
  const selected = conversations.find(conversation => conversation.id === selectedId)
  useEffect(() => { if (!conversations.length) { const created: Conversation = { id: crypto.randomUUID(), title: 'New conversation', created: Date.now(), updated: Date.now(), messages: [] }; setConversations([created]); setSelectedId(created.id) } else if (!conversations.some(item => item.id === selectedId)) setSelectedId(conversations[0].id) }, [conversations, selectedId, setConversations])
  useEffect(() => { if (conversations.length) saveConversations(conversations) }, [conversations])
  const update = (id: string, fn: (conversation: Conversation) => Conversation) => setConversations(items => items.map(item => item.id === id ? fn(item) : item))
  const create = () => { const created: Conversation = { id: crypto.randomUUID(), title: 'New conversation', created: Date.now(), updated: Date.now(), messages: [] }; setConversations(items => [created, ...items]); setSelectedId(created.id) }
  const send = async () => {
    const body = draft.trim(); if (!body || sending || !selected) return
    const userMessage: ChatMessage = { id: crypto.randomUUID(), role: 'user', body, created: Date.now() }
    update(selected.id, item => ({ ...item, title: item.messages.length ? item.title : body.slice(0, 34), updated: Date.now(), messages: [...item.messages, userMessage] })); setDraft(''); setSending(true)
    try { const response = await api.chat(body, selected.id); update(selected.id, item => ({ ...item, updated: Date.now(), messages: [...item.messages, { id: crypto.randomUUID(), role: 'assistant', body: response.reply, created: Date.now() }] })) }
    catch (error) { notify(error instanceof Error ? error.message : 'The backend could not complete chat.', 'error') }
    finally { setSending(false) }
  }
  return <><SectionTitle eyebrow="INTELLIGENCE" title="AI Chat" body="Authenticated conversations with the PlayzAI backend. Provider failures stay visible." action={<button className="button primary" onClick={create}><Plus size={16} /> New conversation</button>} /><div className="chat-layout"><aside className="conversation-rail"><div className="rail-title"><span>Conversations</span><span>{conversations.length}</span></div><button className="new-chat" onClick={create}><Plus size={16} /> Start a new thread</button><div className="conversation-items">{conversations.map(item => <button key={item.id} className={`conversation-item ${selectedId === item.id ? 'active' : ''}`} onClick={() => setSelectedId(item.id)}><MessageSquare size={16} /><span><strong>{item.title}</strong><small>{item.messages.length ? `${item.messages.length} messages · ${relativeTime(item.updated)}` : 'Empty thread'}</small></span><ChevronRight size={14} /></button>)}</div><div className="rail-foot"><Lock size={13} /> Conversation list is stored in this browser tab. Backend message persistence is used by the API.</div></aside><section className="chat-window"><div className="chat-head"><div><span className="eyebrow">PLAYZAI ASSISTANT</span><h3>{selected?.title ?? 'New conversation'}</h3></div><div className="chat-head-actions"><span className="secure-label"><Shield size={13} /> Authenticated</span>{selected && <button className="icon-button" onClick={() => update(selected.id, item => ({ ...item, messages: [], updated: Date.now() }))} title="Clear conversation"><Trash2 size={16} /></button>}</div></div><div className="messages-area">{!selected?.messages.length && <div className="chat-welcome"><div className="welcome-orb"><Sparkles size={28} /></div><h2>What should we<br /><em>think through?</em></h2><p>Ask about planning, explanations, or safe control workflows. The backend decides whether AI is available.</p><div className="prompt-grid"><button onClick={() => setDraft('Give me a concise system status summary.')}>System status summary <ArrowUpRight size={14} /></button><button onClick={() => setDraft('Help me plan a safe device workflow.')}>Plan a safe workflow <ArrowUpRight size={14} /></button></div></div>}{selected?.messages.map(message => <MessageBubble key={message.id} message={message} />)}{sending && <div className="message-row assistant"><div className="message-avatar"><Sparkles size={15} /></div><div className="typing"><span /><span /><span /></div></div>}</div><div className="composer-wrap"><div className="composer"><textarea value={draft} onChange={event => setDraft(event.target.value)} onKeyDown={event => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); void send() } }} placeholder="Message PlayzAI..." rows={1} /><button className="send-button" onClick={() => void send()} disabled={!draft.trim() || sending} aria-label="Send message"><Send size={18} /></button></div><span className="composer-hint"><span>Enter</span> to send <span>Shift + Enter</span> for a new line</span></div></section></div></>
}

function MessageBubble({ message }: { message: ChatMessage }) {
  const [copied, setCopied] = useState(false)
  const copy = async () => { await navigator.clipboard?.writeText(message.body); setCopied(true); window.setTimeout(() => setCopied(false), 1200) }
  return <div className={`message-row ${message.role}`}><div className="message-avatar">{message.role === 'assistant' ? <Sparkles size={15} /> : <UserRound size={15} />}</div><div className="message-content"><div className="message-meta"><strong>{message.role === 'assistant' ? 'PlayzAI' : 'You'}</strong><time>{formatTime(message.created)}</time></div><div className="message-bubble"><RichText body={message.body} /></div><button className="copy-button" onClick={() => void copy()}><Copy size={12} />{copied ? 'Copied' : 'Copy'}</button></div></div>
}

function RichText({ body }: { body: string }) {
  const chunks = body.split(/```/g)
  return <div className="rich-text">{chunks.map((chunk, index) => index % 2 === 1 ? <pre key={index}><code>{chunk.replace(/^\w+\n/, '')}</code></pre> : chunk.split('\n').map((line, lineIndex) => <p key={`${index}-${lineIndex}`}>{line || '\u00a0'}</p>))}</div>
}

function DevicesPage({ ...ctx }: Context) {
  const { devices, api, notify, masterKey, go } = ctx
  const [pairName, setPairName] = useState('Windows PC')
  const [pairing, setPairing] = useState<{ code: string; expires?: number } | null>(null)
  const [busy, setBusy] = useState(false)
  const generate = async () => { setBusy(true); try { const result = await api.pairingCode(pairName); setPairing({ code: result.pairing_code, expires: result.expires_at }); notify('One-time pairing code generated.', 'success') } catch (error) { notify(error instanceof Error ? error.message : 'Pairing code could not be generated.', 'error') } finally { setBusy(false) } }
  const revoke = async (device: Device) => { if (!masterKey) { notify('Enter the owner master key in Settings before revoking a device.', 'error'); return } if (!window.confirm(`Revoke ${device.name}? This will block the device and revoke its sessions.`)) return; try { await api.revokeDevice(device.device_id, masterKey, true); notify(`${device.name} was revoked.`, 'success'); await ctx.refresh() } catch (error) { notify(error instanceof Error ? error.message : 'Device revoke failed.', 'error') } }
  return <><SectionTitle eyebrow="CONTROL PLANE" title="Devices" body="Every state below comes from an authenticated backend response." action={<button className="button subtle" onClick={() => void ctx.refresh()}><RefreshCw size={16} /> Refresh devices</button>} /><div className="device-toolbar"><div><span className="toolbar-count">{devices.length}</span><span>registered devices</span></div><div className="pair-form"><input value={pairName} onChange={event => setPairName(event.target.value)} aria-label="PC name" /><button className="button primary" onClick={() => void generate()} disabled={busy}><Plus size={16} /> {busy ? 'Generating...' : 'Generate pairing code'}</button></div></div>{pairing && <div className="pairing-banner"><div className="pairing-icon"><FileKey2 size={21} /></div><div><strong>One-time pairing code</strong><p>Give this code to the Windows agent. It expires {pairing.expires ? formatTime(pairing.expires) : 'according to backend policy'}.</p></div><code>{pairing.code}</code><button className="icon-button" onClick={() => void navigator.clipboard?.writeText(pairing.code)} title="Copy pairing code"><Copy size={16} /></button><button className="icon-button" onClick={() => setPairing(null)} title="Dismiss"><X size={16} /></button></div>}<div className="devices-grid">{devices.length ? devices.map(device => <DeviceCard key={device.device_id} device={device} onRevoke={device.device_id !== ctx.auth.deviceId ? () => void revoke(device) : undefined} onOpen={() => device.kind === 'pc' && go('pc')} />) : <EmptyState icon={Smartphone} title="No device data returned" body="Register or pair a device through the authenticated backend, then refresh this page." />}</div></>
}

function DeviceCard({ device, onRevoke, onOpen }: { device: Device; onRevoke?: () => void; onOpen: () => void }) {
  const pc = device.kind === 'pc'
  return <article className={`device-card ${pc ? 'pc-card' : ''}`}><div className="device-card-top"><div className={`device-avatar ${pc ? 'pc' : 'phone'}`}>{pc ? <Monitor size={22} /> : <Smartphone size={22} />}</div><StatusPill value={device.status} /></div><div className="device-title"><div><h3>{device.name || 'Registered device'}</h3><span className="mono">{device.device_id}</span></div><button className="icon-button" onClick={onOpen} title="View details"><MoreHorizontal size={17} /></button></div><div className="device-info"><div><span>Last seen</span><strong>{relativeTime(device.last_seen)}</strong></div><div><span>Authentication</span><strong>{device.authenticated ? 'This session' : 'Registered'}</strong></div>{pc && <div><span>Agent</span><strong>{device.agent_version || 'Unavailable'}</strong></div>}</div>{pc && <div className="device-metrics"><MiniMetric icon={Cpu} label="CPU" value={device.metrics?.cpu_percent} /><MiniMetric icon={Activity} label="RAM" value={device.metrics?.ram_percent} /></div>}<div className="device-card-actions">{pc && <button className="button small" onClick={onOpen}>Open control <ArrowUpRight size={14} /></button>}{onRevoke && <button className="button small danger-outline" onClick={onRevoke}><ShieldAlert size={14} /> Revoke</button>}</div></article>
}

function PcControlPage({ ...ctx }: Context) {
  const { pcs, api, notify, commands, go } = ctx
  const [selectedId, setSelectedId] = useState(pcs[0]?.id ?? '')
  const [running, setRunning] = useState<string | null>(null)
  const selected = pcs.find(pc => pc.id === selectedId) ?? pcs[0]
  useEffect(() => { if (!selectedId && pcs[0]) setSelectedId(pcs[0].id) }, [pcs, selectedId])
  const runAction = async (action: string, args: Record<string, unknown> = {}, dangerous = false) => {
    if (!selected) { notify('No configured PC was returned by the backend.', 'error'); return }
    if (dangerous && !window.confirm(`Confirm ${action.replaceAll('_', ' ')} on ${selected.name}?`)) return
    setRunning(action)
    try { const result = await api.command(selected.device_id, action, args, dangerous); if (result.requires_confirmation) notify('The backend requires explicit confirmation for this action.', 'error'); else { notify(`Command ${action} queued. Waiting for the agent result.`, 'success'); await ctx.refresh(true) } } catch (error) { notify(error instanceof Error ? error.message : 'The command could not be queued.', 'error') } finally { setRunning(null) }
  }
  const wake = async () => { if (!selected) return; if (!window.confirm(`Send Wake-on-LAN to ${selected.name}?`)) return; try { const result = await api.wakePc(selected.id, true); notify(String(result.message ?? result.wake_on_lan ?? 'Wake request returned.'), result.ok === false ? 'error' : 'success') } catch (error) { notify(error instanceof Error ? error.message : 'Wake-on-LAN failed.', 'error') } }
  const actions = [{ label: 'Lock PC', action: 'lock_pc', icon: Lock, dangerous: true }, { label: 'Shutdown', action: 'shutdown', icon: Power, dangerous: true }, { label: 'Restart', action: 'restart', icon: RefreshCw, dangerous: true }, { label: 'Sleep', action: 'sleep_pc', icon: Moon, dangerous: true }, { label: 'Notepad', action: 'open_app', icon: Code2, args: { name: 'notepad' } }, { label: 'Calculator', action: 'open_app', icon: Gauge, args: { name: 'calculator' } }, { label: 'Get status', action: 'get_status', icon: Activity }, { label: 'Notify Windows', action: 'notify', icon: Bell, args: { message: 'PlayzAI dashboard notification' } }]
  return <><SectionTitle eyebrow="REMOTE CONTROL" title="PC Control" body="Only backend-allowlisted actions are shown. Every command keeps its backend status." action={<button className="button subtle" onClick={() => void ctx.refresh()}><RefreshCw size={16} /> Sync agent</button>} />{pcs.length ? <><div className="pc-selector"><div className="pc-selector-title"><div className="device-avatar pc"><Monitor size={22} /></div><div><span className="eyebrow">SELECTED MACHINE</span><h2>{selected?.name ?? 'Windows PC'}</h2></div><StatusPill value={selected?.status} /></div><select value={selected?.id ?? ''} onChange={event => setSelectedId(event.target.value)} aria-label="Select PC">{pcs.map(pc => <option key={pc.id} value={pc.id}>{pc.name} · {statusLabel(pc.status)}</option>)}</select></div><div className="pc-control-grid"><Panel title="Live telemetry" subtitle="Last authenticated heartbeat"><div className="telemetry-large"><Telemetry icon={Cpu} label="CPU usage" value={selected?.cpu_percent} /><Telemetry icon={Activity} label="Memory usage" value={selected?.ram_percent} /><Telemetry icon={HardDrive} label="Storage usage" value={selected?.storage_percent} /></div><div className="network-line"><Network size={16} /><span>Network</span><strong>{selected?.network_status || 'Unavailable'}</strong><StatusPill value={selected?.network_status} /></div><div className="agent-meta"><span>Agent version <strong>{selected?.agent_version || 'Unavailable'}</strong></span><span>Last heartbeat <strong>{relativeTime(selected?.last_seen)}</strong></span></div></Panel><Panel title="Safe actions" subtitle="Destructive actions require confirmation"><div className="actions-grid">{actions.map(item => <button key={item.action} className={`action-tile ${item.dangerous ? 'danger-action' : ''}`} onClick={() => void runAction(item.action, item.args, item.dangerous)} disabled={running !== null}><span className="action-icon"><item.icon size={18} /></span><span>{item.label}</span>{running === item.action ? <RefreshCw className="spin" size={14} /> : <ArrowUpRight size={14} />}</button>)}</div><button className="wol-button" onClick={() => void wake()} disabled={selected?.wake_on_lan !== 'configured'}><Zap size={17} /> Wake-on-LAN <span>{selected?.wake_on_lan === 'configured' ? 'Configured' : 'Not configured'}</span></button></Panel></div><Panel title="Recent command outcomes" subtitle="The dashboard does not mark a command successful until it sees backend result state." action={<button className="text-button" onClick={() => go('commands')}>Full history <ArrowUpRight size={14} /></button>}><CommandTable commands={commands.filter(command => command.target_device_id === selected?.device_id).slice(0, 5)} /></Panel></> : <EmptyState icon={Monitor} title="No PC configured" body="Pair a Windows agent and send a heartbeat before using PC Control." action={<button className="button primary" onClick={() => go('devices')}>Go to Devices</button>} />}</>
}

function Telemetry({ icon: Icon, label, value }: { icon: typeof Cpu; label: string; value?: number | null }) { return <div className="telemetry"><div className="telemetry-head"><span><Icon size={16} />{label}</span><strong><MetricValue value={value} suffix="%" /></strong></div><ProgressBar value={value} /></div> }

function SecurityPage({ ...ctx }: Context) {
  const { events, devices, api, notify, masterKey, setMasterKey } = ctx
  const blocked = devices.filter(device => statusKey(device.status) === 'danger')
  const failed = events.filter(event => event.event?.includes('failed')).length
  const lockdown = blocked.length > 0
  const secureAction = async (kind: 'lock' | 'unlock') => { if (!masterKey) { notify('Enter the owner master key in Settings before changing lockdown.', 'error'); return } if (!window.confirm(`${kind === 'lock' ? 'Enable lockdown' : 'Disable lockdown'}?`)) return; try { if (kind === 'lock') await api.lockdown(masterKey); else await api.unlock(masterKey); notify(kind === 'lock' ? 'Lockdown enabled by backend.' : 'Lockdown disabled. Re-authentication may be required.', 'success'); await ctx.refresh() } catch (error) { notify(error instanceof Error ? error.message : 'Security action failed.', 'error') } }
  return <><SectionTitle eyebrow="PROTECTION LAYER" title="Security Center" body="The security view is deliberately evidence-led: no synthetic risk scores or invented telemetry." action={<button className="button subtle" onClick={() => void ctx.refresh()}><RefreshCw size={16} /> Refresh events</button>} /><div className={`security-hero ${lockdown ? 'locked' : ''}`}><div className="security-emblem">{lockdown ? <Lock size={31} /> : <Shield size={31} />}</div><div><span className="eyebrow">CURRENT SECURITY STATE</span><h2>{lockdown ? 'Locked down' : 'Protected by backend policy'}</h2><p>{lockdown ? 'At least one device is blocked. Re-authentication and owner control are required.' : 'No blocked device was returned in the current backend snapshot.'}</p></div><StatusPill value={lockdown ? 'blocked' : 'protected'} /></div><div className="security-stats"><StatCard label="Failed auth events" value={String(failed)} detail={failed ? 'Review audit log' : 'No returned failures'} icon={ShieldAlert} tone="red" /><StatCard label="Blocked devices" value={String(blocked.length)} detail={blocked.length ? 'Action required' : 'None returned'} icon={Lock} tone="amber" /><StatCard label="Authenticated here" value={devices.filter(device => device.authenticated).length ? 'Yes' : 'Unknown'} detail="Current device evidence" icon={UserRound} tone="green" /></div><div className="security-actions"><Panel title="Owner controls" subtitle="Master key is used only in memory for this action."><label className="inline-secret">Owner master key<input type="password" value={masterKey} onChange={event => setMasterKey(event.target.value)} placeholder="Not stored in dashboard" /></label><div className="control-buttons"><button className="button danger" onClick={() => void secureAction('lock')}><Lock size={16} /> Enable lockdown</button><button className="button subtle" onClick={() => void secureAction('unlock')}><Unlock size={16} /> Disable lockdown</button></div><div className="explain-row"><Shield size={16} /><span>Lockdown blocks registered devices for the backend policy window and revokes active sessions. The backend remains the source of truth.</span></div></Panel><Panel title="Recent security events" subtitle="Last 100 events returned by the backend"><ActivityList events={events.slice(0, 10)} commands={[]} /></Panel></div></>
}

function CommandsPage({ commands, go }: Context) {
  const [filter, setFilter] = useState('')
  const filtered = commands.filter(command => `${command.action} ${command.status} ${command.target_device_id} ${command.requested_by}`.toLowerCase().includes(filter.toLowerCase()))
  return <><SectionTitle eyebrow="EXECUTION HISTORY" title="Commands" body="A command is only successful when the backend receives a result from the authenticated agent." action={<button className="button subtle" onClick={() => go('pc')}><Terminal size={16} /> Open PC control</button>} /><div className="filter-bar"><div className="search-field"><Search size={16} /><input value={filter} onChange={event => setFilter(event.target.value)} placeholder="Filter device, command, status..." /></div><span className="filter-result">{filtered.length} result{filtered.length === 1 ? '' : 's'}</span></div><Panel title="Command history" subtitle="Backend command queue and results"><CommandTable commands={filtered} expanded /></Panel></>
}

function CommandTable({ commands, expanded = false }: { commands: Command[]; expanded?: boolean }) {
  if (!commands.length) return <EmptyState icon={Terminal} title="No commands returned" body="Commands will appear here after an authenticated dashboard action is queued." />
  return <div className="table-wrap"><table><thead><tr><th>Time</th><th>Device</th><th>Command</th><th>Status</th><th>Requested by</th>{expanded && <th>Result</th>}</tr></thead><tbody>{commands.map(command => <tr key={command.id ?? command.command_id}><td>{formatTime(command.created)}</td><td className="mono">{command.target_device_id ?? 'Unavailable'}</td><td><strong>{command.action ?? 'Unknown'}</strong></td><td><StatusPill value={command.status} /></td><td className="mono">{command.requested_by ?? 'Unavailable'}</td>{expanded && <td className="result-cell">{command.result_json || 'Awaiting agent result'}</td>}</tr>)}</tbody></table></div>
}

function ConversationsPage({ conversations, setConversations, go }: Context) {
  const [search, setSearch] = useState('')
  const filtered = conversations.filter(item => item.title.toLowerCase().includes(search.toLowerCase()))
  const remove = (id: string) => { if (window.confirm('Delete this browser conversation? Backend message records are not deleted by this local action.')) { const next = conversations.filter(item => item.id !== id); setConversations(next); saveConversations(next) } }
  return <><SectionTitle eyebrow="MEMORY LAYER" title="Conversations" body="The backend persists messages; this browser keeps a lightweight navigation index because no conversation-list endpoint is exposed." action={<button className="button primary" onClick={() => go('chat')}><MessageSquare size={16} /> Open AI chat</button>} /><div className="filter-bar"><div className="search-field"><Search size={16} /><input value={search} onChange={event => setSearch(event.target.value)} placeholder="Search browser conversation index..." /></div></div><div className="conversation-table">{filtered.length ? filtered.map(item => <div className="conversation-row" key={item.id}><div className="conversation-row-icon"><MessageSquare size={17} /></div><div className="conversation-row-copy"><strong>{item.title}</strong><span>Created {formatTime(item.created)} · {item.messages.length} browser-indexed messages · Last updated {relativeTime(item.updated)}</span></div><button className="button small" onClick={() => go('chat')}>Open <ArrowUpRight size={13} /></button><button className="icon-button" onClick={() => remove(item.id)} title="Delete local index"><Trash2 size={16} /></button></div>) : <EmptyState icon={Archive} title="No conversations in this browser" body="Start a backend chat to create a conversation index." />}</div></>
}

function WhatsAppPage({ whatsapp }: Context) {
  const configured = whatsapp?.configured === true
  return <><SectionTitle eyebrow="OFFICIAL MESSAGING" title="WhatsApp" body="This dashboard reports only the official WhatsApp Business / Cloud API boundary." /><div className={`integration-hero ${configured ? 'ready' : ''}`}><div className="integration-icon"><Phone size={25} /></div><div><span className="eyebrow">CLOUD API STATUS</span><h2>{configured ? 'Configured' : 'Not configured'}</h2><p>{configured ? 'The backend reports the required Cloud API configuration is present.' : 'The backend reports WhatsApp is not configured. No delivery is claimed.'}</p></div><StatusPill value={configured} /></div><div className="integration-grid"><Panel title="Configuration evidence" subtitle="Secrets are never returned to the dashboard"><EvidenceRow label="Official Cloud API boundary" value={whatsapp?.official_cloud_api ? 'Available' : 'Unavailable'} status={whatsapp?.official_cloud_api} /><EvidenceRow label="Backend configuration" value={configured ? 'Configured' : 'Not configured'} status={configured} /><EvidenceRow label="Voice processing" value={whatsapp?.voice_transcription ?? 'Not reported'} status={whatsapp?.voice_transcription === 'configured'} /><EvidenceRow label="Credentials" value="Never exposed" status="online" /></Panel><Panel title="Operator note"><div className="note-box"><Lock size={18} /><p>Configure the official Business Cloud API credentials, verify token, webhook secret, phone number ID, and public HTTPS webhook on the backend. Personal-account automation is not supported.</p></div></Panel></div></>
}

function EvidenceRow({ label, value, status }: { label: string; value: string; status?: string | boolean }) { return <div className="evidence-row"><span>{label}</span><strong>{value}</strong><StatusPill value={status} /></div> }

function AuditPage({ events }: Context) {
  const [search, setSearch] = useState('')
  const [severity, setSeverity] = useState('all')
  const filtered = events.filter(event => { const text = `${event.event} ${event.source} ${event.detail} ${event.ip}`.toLowerCase(); const matches = text.includes(search.toLowerCase()); const isDanger = event.event?.includes('failed') || event.event?.includes('denied') || event.event?.includes('revoked'); return matches && (severity === 'all' || (severity === 'danger' ? isDanger : !isDanger)) })
  return <><SectionTitle eyebrow="OBSERVABILITY" title="Activity / Audit Logs" body="Searchable events returned by the backend. IP values are displayed only when the backend provides them." /><div className="filter-bar audit-filters"><div className="search-field"><Search size={16} /><input value={search} onChange={event => setSearch(event.target.value)} placeholder="Search event, device, detail, IP..." /></div><select value={severity} onChange={event => setSeverity(event.target.value)}><option value="all">All severity</option><option value="danger">Action required</option><option value="normal">Normal activity</option></select></div><Panel title="Audit trail" subtitle={`${filtered.length} of ${events.length} returned events`}><div className="audit-list">{filtered.length ? filtered.map(event => { const danger = event.event?.includes('failed') || event.event?.includes('denied') || event.event?.includes('revoked'); return <div className="audit-row" key={String(event.id)}><span className={`audit-severity ${danger ? 'danger' : 'normal'}`} /><div className="audit-time"><Clock3 size={14} />{formatTime(event.ts)}</div><div className="audit-main"><strong>{event.event ?? 'Backend event'}</strong><span>{event.detail ?? 'No detail returned'}</span></div><span className="audit-source">{event.source ?? 'Backend'}</span><span className="audit-ip">{event.ip ?? 'Not provided'}</span></div> }) : <EmptyState icon={Activity} title="No matching events" body="Try a different search or refresh backend activity." />}</div></Panel></>
}

function SettingsPage({ theme, setTheme, ...ctx }: Context & { theme: string; setTheme: (theme: string) => void }) {
  const { auth, health, api, notify, setMasterKey, masterKey } = ctx
  const [url, setUrl] = useState(auth.baseUrl)
  const [testStatus, setTestStatus] = useState('')
  const [notifications, setNotifications] = useState(() => sessionStorage.getItem('playzai.dashboard.notifications') !== 'off')
  const test = async () => { setTestStatus('Testing...'); try { const result = await api.health(); setTestStatus(result.ok ? 'Backend healthy' : 'Backend returned an unhealthy state') } catch (error) { setTestStatus(error instanceof Error ? error.message : 'Connection failed') } }
  const applyEndpoint = () => { const next = { ...auth, baseUrl: normalizeBaseUrl(url) }; saveAuth(next); window.location.reload() }
  const toggleNotifications = (value: boolean) => { setNotifications(value); sessionStorage.setItem('playzai.dashboard.notifications', value ? 'on' : 'off') }
  return <><SectionTitle eyebrow="CONFIGURATION" title="Settings" body="Dashboard preferences are local to this browser session. Backend secrets remain external." /><div className="settings-grid"><Panel title="General" subtitle="Personalize the control center"><SettingRow icon={Moon} label="Theme" help="Dark-first premium interface"><select value={theme} onChange={event => setTheme(event.target.value)}><option value="dark">Dark</option><option value="light">Light</option></select></SettingRow><SettingRow icon={Globe2} label="Language" help="Dashboard UI language"><select defaultValue="English"><option>English</option><option disabled>Hindi — backend localization available in Android</option></select></SettingRow></Panel><Panel title="Backend connection" subtitle="The configured endpoint used by this dashboard"><label className="field-label">Backend URL<input value={url} onChange={event => setUrl(event.target.value)} /></label><div className="settings-inline"><button className="button subtle" onClick={() => void test()}><Wifi size={16} /> Test current connection</button><button className="button primary" onClick={applyEndpoint} disabled={!url.trim()}><Check size={16} /> Apply and reconnect</button><span className={testStatus.includes('healthy') ? 'success-text' : 'muted'}>{testStatus || (health?.ok ? 'Last check healthy' : 'No confirmed health check')}</span></div><div className="setting-note"><Server size={15} /> Changing the URL applies on the next connection. Current session remains bound to <span className="mono">{auth.deviceId}</span>.</div></Panel><Panel title="Security" subtitle="Owner secrets are not persisted by the dashboard"><label className="field-label">Owner master key<input type="password" value={masterKey} onChange={event => setMasterKey(event.target.value)} placeholder="Required for lockdown/revoke actions" /></label><div className="settings-inline"><button className="button danger-outline" onClick={() => { sessionStorage.removeItem('playzai.dashboard.auth'); notify('Session cleared from this browser tab.', 'success') }}><LogOut size={16} /> Clear stored session</button><span className="muted">API key and session token are held in session memory.</span></div></Panel><Panel title="Notifications" subtitle="Only browser dashboard notifications"><SettingRow icon={Bell} label="Dashboard alerts" help="Show success and error toasts"><button className={`toggle ${notifications ? 'on' : ''}`} onClick={() => toggleNotifications(!notifications)} aria-label="Toggle dashboard alerts"><span /></button></SettingRow></Panel><Panel title="About PlayzAI" subtitle="Build information"><div className="about-inline"><div className="brand-mark"><Sparkles size={18} /></div><div><strong>PlayzAI Control Center</strong><span>Version 1.4.0 · Made by SatyamPlayz</span></div><span className="version-chip">WEB DASHBOARD</span></div></Panel></div></>
}

function SettingRow({ icon: Icon, label, help, children }: { icon: typeof Moon; label: string; help: string; children: React.ReactNode }) { return <div className="setting-row"><span className="setting-icon"><Icon size={17} /></span><div><strong>{label}</strong><small>{help}</small></div>{children}</div> }

function AboutPage({ go }: { go: (page: PageKey) => void }) { return <><SectionTitle eyebrow="THE PLAYZAI SYSTEM" title="About PlayzAI" body="A calm interface for authenticated intelligence and safe device control." /><div className="about-hero"><div className="about-mark"><Sparkles size={42} /></div><div><span className="eyebrow">PLAYZAI 1.4.0</span><h2>Made for clarity.<br /><em>Built for control.</em></h2><p>PlayzAI is a security-first personal control layer. It keeps provider credentials on the backend, reports only observed device state, and refuses to turn unavailable services into reassuring fiction.</p><div className="about-actions"><button className="button primary" onClick={() => go('overview')}>Return to overview <ArrowUpRight size={16} /></button><button className="button subtle" onClick={() => go('security')}><Shield size={16} /> Review security</button></div></div></div><div className="principles-grid"><Principle icon={Shield} title="Truthful by default" text="Unavailable, offline, and not configured remain explicit states." /><Principle icon={Lock} title="Backend-owned security" text="Authentication, policy, commands, and audit evidence stay server-side." /><Principle icon={Sparkles} title="Human-scale design" text="Premium depth and motion without hiding what a system actually knows." /></div></> }
function Principle({ icon: Icon, title, text }: { icon: typeof Shield; title: string; text: string }) { return <div className="principle"><span className="principle-icon"><Icon size={18} /></span><strong>{title}</strong><p>{text}</p></div> }

export default function App() {
  const [auth, setAuth] = useState<AuthState | null>(readSavedAuth)
  const authenticate = (next: AuthState) => { saveAuth(next); setAuth(next) }
  return auth ? <Dashboard auth={auth} onLogout={() => setAuth(null)} /> : <AuthScreen onAuthenticated={authenticate} />
}
